
#include <omnetpp.h>
#include <sstream>
#include <string>
#include <vector>
#include <iostream>
#include <vector>
#include <string>
#include <cstdlib>
#include <ctime>
#include <algorithm>
#include <iomanip>
#include <sstream>
#include "randomScenario.h"
using namespace omnetpp;
//using namespace inet;


Define_Module(randomScenario);


void randomScenario::initialize()
{

    std::vector<WiredNodeInfo> topo = getWiredTopologyInfo();
    for (const auto& nodeInfo : topo) {
        EV << "Node Name: " << nodeInfo.nodeName << ", "
           << "Gate Name: " << nodeInfo.gateName << ", "
           << "Remote Node: " << nodeInfo.remoteNode << ", "
           << "Remote Gate: " << nodeInfo.remoteGate << "\n";
    }
}

std::vector<WiredNodeInfo> randomScenario::getWiredTopologyInfo() {
    std::vector<WiredNodeInfo> topologyInfo;
    cTopology topo;

    // 选择函数，用于提取有线网络节点
    auto includeWiredNodes = [](cModule *mod, void *){
        return true; // 假设所有节点都是有线节点
    };

    // 从网络中提取有线拓扑
    topo.extractFromNetwork(includeWiredNodes, nullptr);

    // 遍历所有节点，收集信息
    for (int i = 0; i < topo.getNumNodes(); ++i) {
        cTopology::Node *node = topo.getNode(i);
        cModule *module = node->getModule();
        std::string moduleName = module->getFullName();

        // 处理有线连接
        for (int j = 0; j < node->getNumOutLinks(); ++j) {
            cTopology::LinkOut *linkOut = node->getLinkOut(j);
            cModule *remoteModule = linkOut->getRemoteNode()->getModule();
            cGate *localGate = linkOut->getLocalGate();
            cGate *remoteGate = linkOut->getRemoteGate();

            // 构建信息并添加到列表中
            WiredNodeInfo info;
            info.nodeName = moduleName;
            info.gateName = localGate->getFullName();
            info.remoteNode = remoteModule->getFullName();
            info.remoteGate = remoteGate->getFullName();
            topologyInfo.push_back(info);
        }
    }

    return topologyInfo;
}

std::vector<std::string> randomScenario::randomTime(int startTime, int endTime, int numTime) {
    if (startTime >= endTime) {
        throw std::invalid_argument("startTime must be less than endTime");
    }

    if (numTime <= 0) {
        throw std::invalid_argument("numTime must be positive");
    }

    // 初始化随机数生成器
    std::srand(std::time(nullptr));

    std::vector<std::string> result;
    for (int i = 0; i < numTime; ++i) {
        double randomNum;
        do {
            // 生成一个位于 [startTime, endTime) 范围内的随机小数
            randomNum = static_cast<double>(startTime) + static_cast<double>(std::rand()) / RAND_MAX * (endTime - startTime);
            // 保留三位小数
            randomNum = static_cast<int>(randomNum * 1000) / 1000.0;
        } while (std::find(operTime.begin(), operTime.end(), randomNum) != operTime.end());

        // 将随机数添加到 operTime 数组中
        operTime.push_back(randomNum);

        // 转换随机数为字符串并添加到结果中
        std::stringstream stream;
        stream << std::fixed << std::setprecision(3) << randomNum;
        result.push_back(stream.str());
    }

    return result;
}
