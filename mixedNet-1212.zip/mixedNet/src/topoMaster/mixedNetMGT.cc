
#include "mixedNetMGT.h"
#include "JsonBase.h"


#include <iostream>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <string>
#include <cctype>
#include <algorithm>
#include <sstream>
#include <utility>
//debug
#include <typeinfo>

using namespace omnetpp;
//using namespace inet;


Define_Module(mixedNetMGT);



void mixedNetMGT::initialize()
{

    topologyUpdateMessage = new cMessage("topologyUpdate");
    updateAndPrintTopology();
    double updateInterval = par("updateInterval").doubleValue();
    scheduleAt(simTime() + updateInterval / 1000.0, topologyUpdateMessage);
    parseRoots(); // get app-related config.
    //tempAppInfo = AppInfo; // BUG: here is late.
    //processAppParsInitialize();
}

void mixedNetMGT::handleMessage(cMessage *msg)
{

    if (msg->isSelfMessage() && msg == topologyUpdateMessage) {
            // 定时更新拓扑信息
            updateAndPrintTopology();
            double updateInterval = par("updateInterval").doubleValue();
            scheduleAt(simTime() + updateInterval / 1000.0, msg);
        }else{
            delete msg;
        }
}

bool includeAllModules(cModule *mod, void *userdata) {
    return true;
}

bool includeTopLevelModules(cModule *mod, void *userdata) {
    return mod->getParentModule() == nullptr;
}

bool includeSecondLevelModules(cModule *mod, void *userdata) {
    cModule *parent = mod->getParentModule();
    return parent != nullptr && parent->getParentModule() == nullptr;
}

bool includeSpecificModules(cModule *mod, void *userdata) {
    cModule *parent = mod->getParentModule();
    if (parent != nullptr && parent->getParentModule() == nullptr) {
        // 检查模块是否有连接到外部的网关
        for (int i = 0; i < mod->gateCount(); ++i) {
            cGate *gate = mod->gateByOrdinal(i);
            if (gate && gate->isConnectedOutside()) {
                return true; // 如果网关连接到外部，包括这个模块
            }
        }
    }
    return false; // 如果不是二级模块或没有连接到外部的网关，不包括这个模块
}

/*
void mixedNetMGT::updateAndPrintTopology() {

    std::stringstream currentTopology;
    std::unordered_set<std::string> currentTopologyModules;

    // 使用选择函数提取网络拓扑
    topo.extractFromNetwork(includeSpecificModules, nullptr);

    // 遍历所有节点，并收集链接信息
    for (int i = 0; i < topo.getNumNodes(); ++i) {
        cTopology::Node *node = topo.getNode(i);
        cModule *module = node->getModule();
        std::string moduleName = module->getFullName();

        // 收集当前拓扑中的模块名称
        currentTopologyModules.insert(moduleName);

        for (int j = 0; j < node->getNumOutLinks(); ++j) {
            cTopology::LinkOut *linkOut = node->getLinkOut(j);
            cModule *remoteModule = linkOut->getRemoteNode()->getModule();
            cGate *localGate = linkOut->getLocalGate();
            cGate *remoteGate = linkOut->getRemoteGate();
            cChannel *channel = localGate->getChannel();

            // 构建并添加链接的详细信息
            currentTopology << moduleName << "." << localGate->getFullName();
            currentTopology << " --> " << remoteModule->getFullName() << "." << remoteGate->getFullName();

            if (channel) {
                currentTopology << " | Rate: " << channel->par("datarate").str() << ", Length: " << channel->par("length").str();
            }

            currentTopology << "\n";
        }
    }

    // 对比当前拓扑和上一次拓扑，识别上线和下线的模块
    //check sw and ap.
    for (const auto& moduleName : currentTopologyModules) {
        if (lastTopologyModules.find(moduleName) == lastTopologyModules.end()) {
            EV << "模块上线: " << moduleName << "\n";

            dynamicDetectApp("UDP", "up", moduleName);

        }
    }
    for (const auto& moduleName : lastTopologyModules) {
        if (currentTopologyModules.find(moduleName) == currentTopologyModules.end()) {

            dynamicDetectApp("UDP", "down", moduleName);
        }
    }

    // 更新上一次拓扑信息
    lastTopologyModules = currentTopologyModules;

    // 对比当前拓扑和上一次拓扑字符串
    std::string currentTopologyStr = currentTopology.str();
    if (currentTopologyStr != lastTopology) {
        // 拓扑发生变化，打印新拓扑
        EV << "拓扑发生变化:\n" << currentTopologyStr;
        lastTopology = currentTopologyStr; // 更新上一次拓扑字符串
    }

}
*/

void mixedNetMGT::updateAndPrintTopology() {
    std::stringstream currentTopology;
    std::unordered_set<std::string> currentTopologyModules;

    // 使用选择函数提取有线网络拓扑
    topo.extractFromNetwork(includeSpecificModules, nullptr);

    // 遍历所有节点，并收集链接信息
    for (int i = 0; i < topo.getNumNodes(); ++i) {
        cTopology::Node *node = topo.getNode(i);
        cModule *module = node->getModule();
        std::string moduleName = module->getFullName();

        // 收集当前拓扑中的模块名称
        currentTopologyModules.insert(moduleName);

        // 处理有线连接
        for (int j = 0; j < node->getNumOutLinks(); ++j) {
            cTopology::LinkOut *linkOut = node->getLinkOut(j);
            cModule *remoteModule = linkOut->getRemoteNode()->getModule();
            cGate *localGate = linkOut->getLocalGate();
            cGate *remoteGate = linkOut->getRemoteGate();
            cChannel *channel = localGate->getChannel();

            // 构建并添加链接的详细信息
            currentTopology << moduleName << "." << localGate->getFullName();
            currentTopology << " LinkTo " << remoteModule->getFullName() << "." << remoteGate->getFullName();
            if (channel) {
                currentTopology << " , Rate: " << channel->par("datarate").str() << ", Length: " << channel->par("length").str();
            }
            currentTopology << "\n";
        }
    }

    // 检查无线节点状态
    cModule *networkModule = getSimulation()->getSystemModule();
    for (cModule::SubmoduleIterator it(networkModule); !it.end(); ++it) {
        cModule *submodule = *it;
        std::string moduleName = submodule->getModuleType()->getName();

        if (moduleName == "WirelessHost" || moduleName == "AccessPoint") {
            inet::NodeStatus *nodeStatus = dynamic_cast<inet::NodeStatus *>(submodule->getSubmodule("status"));
            if (nodeStatus) {
                inet::NodeStatus::State currentState = nodeStatus->getState();
                std::string modulePath = submodule->getFullPath();
                std::string nodeName = deleteFirstEle(modulePath);

                if (currentState == inet::NodeStatus::UP) {
                    // 添加无线模块状态到拓扑
                    currentTopology <<"WirelessStatus:\n"<<nodeName << ", " << getStateString(currentState) << "\n";
                    currentTopologyModules.insert(nodeName);
                } else if (currentState == inet::NodeStatus::DOWN) {
                    // 从拓扑中移除无线模块
                    currentTopologyModules.erase(nodeName);
                }

                // 如果状态改变，记录到日志
                if (wirelessNodeStatus[modulePath] != currentState) {
                    wirelessNodeStatus[modulePath] = currentState;
                    EV << "Node: " << nodeName << " status changed to " << getStateString(currentState) << endl;
                }
            }
        }
    }
    for (const auto& moduleName : currentTopologyModules) {
        if (lastTopologyModules.find(moduleName) == lastTopologyModules.end()) {
            EV << "模块上线: " << moduleName << "\n";

            dynamicDetectApp("UDP", "up", moduleName);

        }
    }
    for (const auto& moduleName : lastTopologyModules) {
        if (currentTopologyModules.find(moduleName) == currentTopologyModules.end()) {

            dynamicDetectApp("UDP", "down", moduleName);
        }
    }
    // 更新拓扑和打印
    std::string currentTopologyStr = currentTopology.str();
    //std::string currentTopologyStr = connectionsToJson(currentTopology.str());

    if (currentTopologyStr != lastTopology) {
        EV << "拓扑发生变化:\n" << currentTopologyStr;

        WriteToSharedMemory(memroyTopoInfo,currentTopologyStr);
        lastTopology = currentTopologyStr;
        EV<<"Get data from CNC: "<<"virtual GCLs and paths"<<endl;
    }
    lastTopologyModules = currentTopologyModules;

}



/*
void mixedNetMGT::WriteToSharedMemory(const std::string& sharedMemoryName, const std::string& data){
    EV<<"writeto, 1"<<endl;
    //const char* shared_memory_name = "/mixedNet_topology_info";
    const int SIZE = 256;
    int fd = shm_open(sharedMemoryName.c_str(), O_CREAT | O_RDWR, 0666);
    ftruncate(fd, SIZE);
    void* ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
    memset(ptr, 0, SIZE); // 清空内存
    *((char*)ptr) = 0; // 设置标志位为0
    sprintf((char*)ptr + 1, "%s", data.c_str()); // 从第二个字节开始写入数据
    *((char*)ptr) = 1; // 设置标志位为1
    munmap(ptr, SIZE);
    close(fd);
}*/

void mixedNetMGT::getFromSharedMemory(const std::string& sharedMemoryName) {
    int fd = shm_open(sharedMemoryName.c_str(), O_RDONLY, 0666);
    if (fd == -1) {
        std::cerr << "Wait for shared memory: " << sharedMemoryName << std::endl;
        return;
    }

    const int SIZE = 1024;  // 预设的共享内存大小
    void* ptr = mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) {
        std::cerr << "Error mapping shared memory: " << sharedMemoryName << std::endl;
        close(fd);
        return;
    }

    std::string readData(static_cast<char*>(ptr), SIZE);
    munmap(ptr, SIZE);
    close(fd);

    if (readData.empty()) {
        std::cerr << "Wait for updating: " << sharedMemoryName << std::endl;
        return;
    }

    if (readData != lastReadData) {
        lastReadData = readData;
        std::cout << "Data from CNC: " << sharedMemoryName << "\n" << readData << std::endl;
    }
}



void mixedNetMGT::WriteToSharedMemory(const std::string& sharedMemoryName, const std::string& data){
    EV<<"writeto, 1"<<endl;
    //const char* shared_memory_name = "/mixedNet_topology_info";
    const int SIZE = 256;
    int fd = shm_open(sharedMemoryName.c_str(), O_CREAT | O_RDWR, 0666);
    ftruncate(fd, SIZE);
    void* ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
    memset(ptr, 0, SIZE); // 清空内存
    //*((char*)ptr) = 0; // 设置标志位为0
    sprintf((char*)ptr, "%s", data.c_str()); // 从第二个字节开始写入数据
    //*((char*)ptr) = 1; // 设置标志位为1
    munmap(ptr, SIZE);
    close(fd);
}

void mixedNetMGT::parseRoots() {
    //mixedNetMGT td;  // 在函数内部创建 mixedNetMGT 的实例
    //EV<<"DEBUG parseRoots"<<endl;
    std::vector<std::string> roots = getParRoots();  // 调用 getParRoots 方法
    for (const std::string& root : roots) {
        //EV<<"App root is :  "<< root << std::endl;  // 打印每个字符串
        processAppParsInitialize(root);
    }
}


std::vector<std::string> mixedNetMGT::getParRoots() {
    std::vector<std::string> appPathArr;
    cModule *networkModule = getSimulation()->getSystemModule();
    cConfiguration *cfg = getEnvir()->getConfig();

    const char* networkName = cfg->getConfigValue("network");
    if (!networkName) {
        return appPathArr;  // 如果未找到网络名称，返回空数组
    }

    std::string networkPath = std::string(networkName) + ".";

    for (cModule::SubmoduleIterator it(networkModule); !it.end(); ++it) {
        cModule *subModule = *it;

        if (subModule && strcmp(subModule->getModuleType()->getName(), "StandardHost") == 0) {
            std::string hostName = subModule->getFullName();
            std::string numAppsPath = networkPath + hostName;
            const char* numAppsStr = cfg->getPerObjectConfigValue(numAppsPath.c_str(), "numApps");
            int numApps = numAppsStr ? atoi(numAppsStr) : 0;

            for (int i = 0; i < numApps; ++i) {
                std::string appPath = networkPath + hostName + ".app[" + std::to_string(i) + "]";
                appPathArr.push_back(appPath);
            }
        }
    }

    return appPathArr;
}


void mixedNetMGT::processAppParsInitialize(const std::string &root) {

    cConfiguration *cfg = getEnvir()->getConfig();

    const char *appTypeName = cfg->getPerObjectConfigValue(root.c_str(), "typename");
    //EV << "appTypeName: " << (appTypeName ? appTypeName : "NULL") << endl;

    if (appTypeName == nullptr || appTypeName[0] == '\0') {
        EV<< "Error: appTypeName is empty" <<endl;
        return;
    }

    std::string appNameStr = appTypeName; // 将 const char* 转换为 std::string
    //return;
    debugCodes(appTypeName,cfg,root);


}
void mixedNetMGT::debugCodes(const std::string& appNameStr,cConfiguration *cfg,const std::string &root){


    if (matchKeyword(appNameStr, "udpsource")) {
        //getUDP();
        //std::string key, std::string udpParStr = getUDPpars(root,cfg);
      auto result = getUDPpars(root,cfg,appNameStr);
      std::string keyName = result.first;
      std::string udpParstr = result.second;
      AppInfo["UDP"][keyName] =udpParstr;

      tempAppInfo = AppInfo;
      std::string appInfo_str = mapToJsonStr();
          EV<<appInfo_str<<endl;
          WriteToSharedMemory(memoryAppInfo,appInfo_str);


//      printAppInfo();

    } else if (matchKeyword(appNameStr, "tcpclient")) {

        std::string tcpParStr = getTCPpars(root,cfg);
    } else {
        EV << "Error: No matching protocol found" << std::endl;
    }



}


std::string mixedNetMGT::splitString(const std::string& input) {
    size_t dotPosition = input.find('.');
    if (dotPosition != std::string::npos) {
        return input.substr(0, dotPosition);
    }
    return input; //return the first element
}


std::string mixedNetMGT::deleteFirstEle(const std::string& input) {
    size_t dotPosition = input.find('.');
    if (dotPosition != std::string::npos) {
        return input.substr(dotPosition + 1);
    }
    return input; //delete the first element
}

//Do not need to consider the NULL string.
std::pair<std::string, std::string> mixedNetMGT::getUDPpars(const std::string &root,cConfiguration *cfg, const std::string &appNameStr){

    std::ostringstream oss;
    std::string dstAddress;
    std::string ioModulePath,sourceModulePath;
    std::string par_packetLen,par_interval;
    std::string hostAppName = deleteFirstEle(root);
    std::string hostName = splitString(hostAppName);
    std::string appIndex = deleteFirstEle(hostAppName);


   EV<<"DEBUG appNameStr is:  "<<appNameStr<<endl;
   EV<<"DEBUG root is:  "<<root<<endl;

  // if(matchKeyword(appNameStr, "source")){
       oss << "hostName: " << hostName << "\n";
       oss << "appIndex: " << appIndex << "\n";

       ioModulePath = root + ".io";
       par_packetLen = "packetLength";
       par_interval = "productionInterval";
       oss << "localPort: " << cfg->getPerObjectConfigValue(ioModulePath.c_str(), "localPort") << "\n";
       sourceModulePath = root + ".source";
       dstAddress =cfg->getPerObjectConfigValue(ioModulePath.c_str(), "destAddress");
       dstAddress.erase(std::remove(dstAddress.begin(), dstAddress.end(), '\"'), dstAddress.end());
       oss << "destAddress: " <<dstAddress<< "\n";
       oss << "destPort: " << cfg->getPerObjectConfigValue(ioModulePath.c_str(), "destPort") << "\n";
       oss << "packetLength: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), par_packetLen.c_str()) << "\n";
       oss << "productionInterval: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), par_interval.c_str()) << "\n";
       std::string keyName =hostAppName+","+ dstAddress;
       return {keyName,oss.str()};

   // }

   /*
   else{

       ioModulePath = root;
       par_packetLen = "messageLength";
       par_interval = "sendInterval";
       sourceModulePath = root;
   }

   dstAddress =cfg->getPerObjectConfigValue(ioModulePath.c_str(), "destAddress");
   dstAddress.erase(std::remove(dstAddress.begin(), dstAddress.end(), '\"'), dstAddress.end());
   oss << "destAddress: " <<dstAddress<< "\n";
   oss << "destPort: " << cfg->getPerObjectConfigValue(ioModulePath.c_str(), "destPort") << "\n";
   oss << "packetLength: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), par_packetLen.c_str()) << "\n";
   oss << "productionInterval: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), par_interval.c_str()) << "\n";*/

   /*
    else if(matchKeyword(appNameStr, "basic")){
        EV<<"**** BASIC UDP *****"<<endl;
        dstAddress =cfg->getPerObjectConfigValue(root.c_str(), "destAddress");
        oss << "destAddress: " <<dstAddress<< "\n";
        oss << "destPort: " << cfg->getPerObjectConfigValue(root.c_str(), "destPort") << "\n";
        oss << "packetLength: " << cfg->getPerObjectConfigValue(root.c_str(), "messageLength") << "\n";
        oss << "sendInterval: " << cfg->getPerObjectConfigValue(root.c_str(), "sendInterval") << "\n";
    }*/

}
std::string mixedNetMGT::getTCPpars(const std::string &root,cConfiguration *cfg ){

    std::ostringstream oss;
    std::string hostAppName = deleteFirstEle(root);
    std::string hostName = splitString(hostAppName);
    std::string appIndex = deleteFirstEle(hostAppName);

    oss << "hostName: " << hostName << "\n";
    oss << "appIndex: " << appIndex << "\n";
    std::string ioModulePath = root + ".io";
    oss << "destAddress: " << cfg->getPerObjectConfigValue(ioModulePath.c_str(), "connectAddress") << "\n";
    oss << "destPort: " << cfg->getPerObjectConfigValue(ioModulePath.c_str(), "connectPort") << "\n";
    std::string sourceModulePath = root + ".source";
    oss << "packetLength: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), "packetLength") << "\n";
    oss << "productionInterval: " << cfg->getPerObjectConfigValue(sourceModulePath.c_str(), "productionInterval") << "\n";
    return oss.str();
}


bool mixedNetMGT::matchKeyword(const std::string& input, const std::string& keyword) {
    std::string lowerInput = input;
    std::string lowerKeyword = keyword;

    // 将输入和关键词转换为小写
    std::transform(lowerInput.begin(), lowerInput.end(), lowerInput.begin(), ::tolower);
    std::transform(lowerKeyword.begin(), lowerKeyword.end(), lowerKeyword.begin(), ::tolower);

    // 检查关键词是否在输入中
    if (lowerInput.find(lowerKeyword) != std::string::npos) {
        return true;  // 返回原始输入字符串
    }

    return false;
}

void mixedNetMGT::printAppInfo() {

    for (const auto& protocolPair : AppInfo) {
        EV << protocolPair.first << ":\n";
        for (const auto& configPair : protocolPair.second) {
            EV << "  " << configPair.first << ": " << configPair.second << "\n";
        }
    }
}

void mixedNetMGT::printTempAppInfo() {
    EV << "Printing temporary AppInfo:\n";
    for (const auto& protocolPair : tempAppInfo) {
        EV << "Protocol: " << protocolPair.first << "\n";
        for (const auto& configPair : protocolPair.second) {
            EV << "  " << configPair.first << ": " << configPair.second << "\n";
        }
    }
}



void mixedNetMGT::dynamicDetectApp(const std::string& appTypeName, const std::string& state, const std::string& moduleName) {
    // 获取 appTypeName 对应的应用信息
    auto& appInfoMap = tempAppInfo[appTypeName];

    if (state == "up") {
        // 节点上线：从 AppInfo 中添加相关信息到 tempAppInfo
        for (const auto& pair : AppInfo[appTypeName]) {
            if (pair.first.find(moduleName) != std::string::npos) {
                appInfoMap[pair.first] = pair.second;
            }
        }
    } else if (state == "down") {
        // 节点下线：从 tempAppInfo 中删除相关信息
        for (auto it = appInfoMap.begin(); it != appInfoMap.end(); ) {
            if (it->first.find(moduleName) != std::string::npos) {
                it = appInfoMap.erase(it);  // 删除与下线模块相关的配置
            } else {
                ++it;
            }
        }
    }

    EV << "tempAppInfo is:\n";
    //printTempAppInfo();
    std::string appInfo_str = mapToJsonStr();
    EV<<appInfo_str<<endl;
    WriteToSharedMemory(memoryAppInfo,appInfo_str);
}


void mixedNetMGT::checkWirelessNodeStatus() {

    //EV<<"debug in wireless"<<endl;
    cModule *networkModule = getSimulation()->getSystemModule();
    for (cModule::SubmoduleIterator it(networkModule); !it.end(); ++it) {
        cModule *submodule = *it;

        // 检查模块类型名称是否匹配 "WirelessHost" 或 "AccessPoint"
        std::string moduleName = submodule->getModuleType()->getName(); //
        //EV<<"*****moduleName is :"<<moduleName<<endl;
        if (moduleName == "WirelessHost" || moduleName == "AccessPoint") {
            // 获取并检查模块的 NodeStatus 子模块
            inet::NodeStatus *nodeStatus = dynamic_cast<inet::NodeStatus *>(submodule->getSubmodule("status"));

            //EV<<"*****nodeStatus is :"<<nodeStatus<<endl;
            if (nodeStatus) {
                inet::NodeStatus::State currentState = nodeStatus->getState();

                // 打印节点的当前状态
                EV << "Node: " << submodule->getFullName() << ", Status: " << getStateString(currentState) << endl;

                // 检查状态是否改变
                std::string modulePath = submodule->getFullPath();
                if (wirelessNodeStatus[modulePath] != currentState) {
                    wirelessNodeStatus[modulePath] = currentState;
                    EV << "Node: " << modulePath << " status changed to " << getStateString(currentState) << endl;
                }
            }
        }
    }

/*
        EV << "Debugging wireless node status" << endl;
        cModule *networkModule = getSimulation()->getSystemModule();
        for (cModule::SubmoduleIterator it(networkModule); !it.end(); ++it) {
            cModule *submodule = *it;
            std::string moduleName = submodule->getModuleType()->getName();
            EV << "Examining module: " << moduleName << endl;

            if (moduleName == "WirelessHost" || moduleName == "AccessPoint") {
                EV << "Found target module: " << moduleName << endl;

                // 打印所有子模块的名称
                for (cModule::SubmoduleIterator subIt(submodule); !subIt.end(); ++subIt) {
                    cModule *childSubmodule = *subIt;
                    std::string childModuleName = childSubmodule->getName();
                    EV << "Submodule: " << childModuleName << endl;
                }

                // 尝试获取并打印NodeStatus子模块的状态
                inet::NodeStatus *nodeStatus = dynamic_cast<inet::NodeStatus *>(submodule->getSubmodule("status", 0));
                if (nodeStatus) {
                    inet::NodeStatus::State currentState = nodeStatus->getState();
                    EV << "Node: " << submodule->getFullName() << ", Status: " << getStateString(currentState) << endl;
                } else {
                    EV << "NodeStatus submodule not found or not accessible in module: " << moduleName << endl;
                }
            }
        }*/


}


const char* mixedNetMGT::getStateString(const inet::NodeStatus::State& state) {
    switch (state) {
        case inet::NodeStatus::UP:
            return "UP";
        case inet::NodeStatus::DOWN:
            return "DOWN";
        case inet::NodeStatus::GOING_UP:
            return "GOING UP";
        case inet::NodeStatus::GOING_DOWN:
            return "GOING DOWN";
        default:
            return "UNKNOWN";
    }
}

std::string mixedNetMGT::mapToStr() {
    std::ostringstream oss;
    for (const auto& outerPair : tempAppInfo) {
        oss << outerPair.first << ": {";
        for (const auto& innerPair : outerPair.second) {
            oss << innerPair.first << ": " << innerPair.second << ", ";
        }
        // Remove the last comma and space
        std::string innerMapStr = oss.str();
        if (!outerPair.second.empty()) {
            innerMapStr = innerMapStr.substr(0, innerMapStr.length() - 2);
        }
        oss.str("");
        oss << innerMapStr << "}, ";
    }
    std::string result = oss.str();
    // Remove the last comma and space
    if (!tempAppInfo.empty()) {
        result = result.substr(0, result.length() - 2);
    }
    return result;
}

std::string mixedNetMGT::mapToJsonStr() {

    std::ostringstream oss;
    oss << "{";
    bool firstOuterPair = true;
    for (const auto& outerPair : tempAppInfo) {
        if (!firstOuterPair) {
            oss << ", ";
        }
        oss << "\"" << outerPair.first << "\": {";
        bool firstInnerPair = true;
        for (const auto& innerPair : outerPair.second) {
            if (!firstInnerPair) {
                oss << ", ";
            }
            oss << "\"" << innerPair.first << "\": {";
            std::istringstream iss(innerPair.second);
            std::string key, value;
            bool firstKeyValue = true;
            while (iss >> key >> value) {
                if (!firstKeyValue) {
                    oss << ", ";
                }
                // Remove the trailing colon from the key if it exists
                if (!key.empty() && key.back() == ':') {
                    key.pop_back();
                }
                oss << "\"" << key << "\": \"" << value << "\"";
                firstKeyValue = false;
            }
            oss << "}";
            firstInnerPair = false;
        }
        oss << "}";
        firstOuterPair = false;
    }
    oss << "}";
    return oss.str();
}

mixedNetMGT::~mixedNetMGT() {
    // 清理工作
    cancelAndDelete(topologyUpdateMessage); // 清理自消息
    topologyUpdateMessage = nullptr;
}
