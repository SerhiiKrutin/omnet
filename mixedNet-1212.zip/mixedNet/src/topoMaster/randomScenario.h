#ifndef RANDOMSCENARIO_H_
#define RANDOMSCENARIO_H_

#include <omnetpp.h>
#include <iostream>
#include <unordered_map>
#include <sstream>
#include <string>
#include "inet/common/lifecycle/NodeStatus.h"
#include "inet/common/ModuleAccess.h"
using namespace omnetpp;
//using namespace inet;

struct WiredNodeInfo {
    std::string nodeName;    // 节点名称
    std::string gateName;    // 节点门的名称
    std::string remoteNode;  // 连接的远程节点名称
    std::string remoteGate;  // 连接的远程节点门的名称
};
std::vector<double> operTime;
class randomScenario : public cSimpleModule {


protected:
  virtual void initialize() override;
  std::vector<WiredNodeInfo> getWiredTopologyInfo();
  std::vector<std::string> randomTime(int startTime, int endTime, int numTime);

};

#endif
