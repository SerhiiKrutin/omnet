
#include <string>
#include <sstream>
#include <vector>
#include "mixedNetMGT.h"



std::string connectionsToJson(const std::string& input) {
    std::istringstream iss(input);
    std::string line;
    std::ostringstream json;
    json << "{";

    // Wired Connections
    json << "\"wiredConnection\": [";
    bool firstWiredConnection = true;
    while (std::getline(iss, line) && !line.empty()) {
        if (line.find(',') != std::string::npos) break; // Stop if wireless status starts
        if (!firstWiredConnection) {
            json << ", ";
        }
        std::istringstream lineStream(line);
        std::string source, arrow, destination, pipe, rate, rateValue, length, lengthValue;
        lineStream >> source >> arrow >> destination >> pipe >> rate >> rateValue >> length >> lengthValue;

        json << "{"
             << "\"source\": \"" << source << "\", "
             << "\"destination\": \"" << destination << "\", "
             << "\"rate\": \"" << rateValue << "\", "
             << "\"length\": \"" << lengthValue << "\""
             << "}";
        firstWiredConnection = false;
    }
    json << "],";

    // Wireless Status
    json << "\"wirelessStatus\": [";
    bool firstWirelessStatus = true;
    do {
        if (!firstWirelessStatus) {
            json << ", ";
        }
        std::string device, status;
        if (line.find(',') != std::string::npos) {
            std::istringstream lineStream(line);
            std::getline(lineStream, device, ',');
            lineStream >> status;
        } else {
            device = line;
            status = "UP";
        }

        json << "{"
             << "\"device\": \"" << device << "\", "
             << "\"status\": \"" << status << "\""
             << "}";
        firstWirelessStatus = false;
    } while (std::getline(iss, line));
    json << "]";

    json << "}";
    return json.str();
}
