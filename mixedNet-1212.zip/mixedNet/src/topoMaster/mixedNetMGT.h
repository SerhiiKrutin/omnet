#ifndef mixedNetMGT_H_
#define mixedNetMGT_H_

#include <omnetpp.h>
#include <iostream>
#include <unordered_map>
#include <sstream>
#include <string>
#include "inet/common/lifecycle/NodeStatus.h"
#include "inet/common/ModuleAccess.h"
using namespace omnetpp;
//using namespace inet;

class mixedNetMGT : public cSimpleModule {

  public:
    virtual ~mixedNetMGT();  // 显式声明析构函数


  private:
    cTopology topo;  // cTopology object to represent network topology
    std::string lastReadData;

  protected:
    // OMNeT++ simulation lifecycle methods

     cMessage  *topologyUpdateMessage;
     std::unordered_map<std::string, std::unordered_map<std::string, std::string>> AppInfo,tempAppInfo;
     std::string lastTopology = "";
     std::unordered_set<std::string> lastTopologyModules;

     std::string memoryAppInfo  = "/mixedNet_app_info";
     std::string memroyTopoInfo = "/mixedNet_topology_info";


    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void updateAndPrintTopology();
    virtual void WriteToSharedMemory(const std::string& sharedMemoryName, const std::string& data);
    virtual void processAppParsInitialize(const std::string& root);
 //   void processAppPars(const std::string& appName);
//static bool containsNonDigit(const std::string& str);
  //  static long parseUnitValue(const std::string& valueStr, const std::string& unit);
    //static std::string safeConvertToString(const char* str);
    std::vector<std::string> getParRoots();
    void parseRoots();
    bool matchKeyword(const std::string& input, const std::string& keyword);
    std::pair<std::string, std::string>  getUDPpars(const std::string &root,cConfiguration *cfg,const std::string &appNameStr);
    std::string getTCPpars(const std::string &root,cConfiguration *cfg);
    std::string splitString(const std::string& input);
    std::string deleteFirstEle(const std::string& input);
    void printAppInfo();
    void dynamicDetectApp(const std::string& appTypeName, const std::string& state, const std::string& moduleName);
    void printTempAppInfo();
    void checkWirelessNodeStatus();
    const char* getStateString(const inet::NodeStatus::State& state);
    std::map<std::string, inet::NodeStatus::State> wirelessNodeStatus; // 声明无线节点状态映射
    void debugCodes(const std::string& appNameStr,cConfiguration *cfg,const std::string &root);
    std::string mapToStr();
    std::string mapToJsonStr();
    void getFromSharedMemory(const std::string& sharedMemoryName);





};

#endif /* CUSTOMMODULE_H_ */
