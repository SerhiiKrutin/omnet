#ifndef NETWORK_STRUCTURES_H
#define NETWORK_STRUCTURES_H

#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <functional>

#include <iostream>


// 定义节点类型枚举
enum class NodeType {
    Terminal,
    Switch
};


// 链路信息结构
struct Link {
    std::string target_node;
    int link_weight;
    int link_rate;
    int link_length;

    Link(std::string target, int weight, int rate, int length) : target_node(target), link_weight(weight), link_rate(rate), link_length(length) {}
};

// 流量路径结构
struct FlowPath {
    std::string flow_name;
    std::vector<std::string> path_nodes;

    FlowPath(std::string name, std::vector<std::string> nodes) : flow_name(name), path_nodes(std::move(nodes)) {}
};

// 流量规格结构
struct FlowSpec {
    std::string flow_name;
    int flow_length;
    int flow_qos;
    int flow_interval; // 新增成员
    int hop_toNow;

    FlowSpec(std::string name, int length, int qos, int hop) 
        : flow_name(name), flow_length(length), flow_qos(qos), hop_toNow(hop), flow_interval(qos) {} // 初始化 flow_interval
};

class Flowsets {
public:
    std::vector<FlowSpec> flows;

    // 添加 FlowSpec 对象到集合
    void addFlow(const FlowSpec& flow) {
        flows.push_back(flow);
    }

    // 根据 qos 或 hop 排序
    void sortFlows(bool sortByQos) {
        if (sortByQos) {
            std::sort(flows.begin(), flows.end(), [](const FlowSpec& a, const FlowSpec& b) {
                return a.flow_qos < b.flow_qos;
            });
        } else {
            std::sort(flows.begin(), flows.end(), [](const FlowSpec& a, const FlowSpec& b) {
                return a.hop_toNow < b.hop_toNow;
            });
        }
    }
};
// 图结构，表示网络拓扑
class Graph {
private:
    std::unordered_map<std::string, std::vector<Link>> adjacency_list;
    std::unordered_map<std::string, std::string> interface_to_device;
    std::unordered_map<std::string, NodeType> node_types;
    std::unordered_map<std::string, int> nodeIndexMap; // 节点名称到索引的映射
    std::vector<std::vector<std::pair<int, int>>> adjList; // 邻接表

public:
    //void addNode(const std::string& node_name);
    void addNode(const std::string& node_name, NodeType type);
    
    void addSingleLink(const std::string& source_interface, const std::string& target_interface, int weight, int rate, int length) {
        std::string source_device = interface_to_device[source_interface];
        std::string target_device = interface_to_device[target_interface];

        // 添加链接从 source_device 到 target_device
        adjacency_list[source_device].emplace_back(target_device, weight, rate, length);
    }

    // 添加双向链接
    void addUndirectedLink(const std::string& interface1, const std::string& interface2, int weight, int rate, int length) {
        addSingleLink(interface1, interface2, weight, rate, length);
        addSingleLink(interface2, interface1, weight, rate, length);
    }

    bool nodeExists(const std::string& node_name) const;
    Link getLink(const std::string& source_node, const std::string& target_node) const;
    void printGraph() const;
    void addInterfaceToDeviceMapping(const std::string& interface_name, const std::string& device_name);
    void updateLinkWeight(const std::string& source_node, const std::string& target_node, int new_weight);
    void printGraphWithInterfaces() const; 
     NodeType getNodeType(const std::string& node_name) const; // 新增方法，获取节点类型


    void updateNodeIndexMap() {
        nodeIndexMap.clear();
        int index = 0;
        for (const auto& node : adjacency_list) {
            nodeIndexMap[node.first] = index++;
        }
        adjList.resize(nodeIndexMap.size()); // 重置邻接表大小
    }

    void updateAdjList() {
        // 清空当前邻接表
        for (auto& list : adjList) {
            list.clear();
        }

        // 填充邻接表
        for (const auto& node : adjacency_list) {
            int nodeIndex = nodeIndexMap[node.first];
            for (const auto& link : node.second) {
                int targetIndex = nodeIndexMap.at(link.target_node);
                adjList[nodeIndex].emplace_back(targetIndex, link.link_weight);
            }
        }
    }

    void printAdjacencyList() const {
    // 遍历邻接表并打印
    for (size_t i = 0; i < adjList.size(); i++) {
        std::cout << "Node " << i << " has links to: ";
        if (adjList[i].empty()) {
            std::cout << "[No links]\n";
        } else {
            for (const auto& pair : adjList[i]) {
                std::cout << "(" << pair.first << ", " << pair.second << ") ";
            }
            std::cout << "\n";
        }
    }
}

std::vector<std::vector<std::pair<int, int>>> toAdjacencyList() {
        // 首先更新节点索引映射和邻接表
        updateNodeIndexMap();
        updateAdjList();

        // 返回邻接表
        return adjList;
    }
    
void printNodeIndexMap() const {
        for (const auto& pair : nodeIndexMap) {
            std::cout << "Node " << pair.first << " has index: " << pair.second << "\n";
        }
    }

};
std::string extractDeviceName(const std::string& interfaceName);
#endif // NETWORK_STRUCTURES_H
