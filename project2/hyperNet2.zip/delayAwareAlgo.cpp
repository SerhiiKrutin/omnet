#include <algorithm>
#include <vector>
#include <limits>
#include <iostream>
#include <cassert>
 
#include <queue>
#include <string>

#include <unordered_map>
using namespace std;

pair<int, string> delayAwareRouting(int source, int sink, int max_hop, const vector<vector<pair<int, int>>>& adjList) {
    int n = adjList.size();
    vector<int> dist(n, numeric_limits<int>::max());
    vector<int> hops(n, numeric_limits<int>::max());
    vector<int> prev(n, -1);

    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
    pq.push({0, source});
    dist[source] = 0;
    hops[source] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        if (u == sink) break;

        for (auto& p : adjList[u]) {
            int v = p.first;
            int weight = p.second;

            if (hops[u] + 1 <= max_hop && dist[v] > dist[u] + weight) {
                dist[v] = dist[u] + weight;
                prev[v] = u;
                hops[v] = hops[u] + 1;
                pq.push({dist[v], v});
            }
        }
    }

    if (dist[sink] == numeric_limits<int>::max()) {
        cout << "Routing error: No path found within max hop count." << endl;
        cout << "Source: " << source << ", Sink: " << sink << ", Max Hop: " << max_hop << endl;
        return {numeric_limits<int>::max(), "Error"};
    }

    string path = to_string(sink);
    for (int v = sink; prev[v] != -1; v = prev[v]) {
        path = to_string(prev[v]) + " -> " + path;
    }

    return {hops[sink], "Cost: " + to_string(dist[sink]) + ", Path: " + path};
}

void printRoutingResult(const pair<int, string>& result) {
    if (result.first != numeric_limits<int>::max()) {
        cout << "Actual Hops: " << result.first << ", " << result.second << endl;
    } else {
        cout << result.second << endl; // 打印错误信息
    }
}



int testForDAR() {
   

    // 小尺寸图测试
    {
        cout<<"Start test case 1"<<endl;
        vector<vector<pair<int, int>>> smallGraph = {
            {{1, 1}, {2, 4}},
            {{0, 1}, {2, 2}, {3, 6}},
            {{0, 4}, {1, 2}, {3, 3}},
            {{1, 6}, {2, 3}}
        };

        auto result = delayAwareRouting(0, 3, 2, smallGraph);
        printRoutingResult(result);


    }
//return 0;
    // 中等尺寸图测试
    {
        cout<<"\nStart test case 2"<<endl;
        vector<vector<pair<int, int>>> mediumGraph = {
            {{1, 7}, {2, 9}, {3, 14}},
            {{0, 7}, {2, 10}, {3, 15}},
            {{0, 9}, {1, 10}, {3, 11}},
            {{0, 14}, {1, 15}, {2, 11}}
        };
    auto result = delayAwareRouting(0, 3, 3, mediumGraph);
    printRoutingResult(result);

    }

    // 大尺寸图测试
    {

        cout<<"\nStart test case 3"<<endl;
        vector<vector<pair<int, int>>> largeGraph = {
            {{1, 4}, {7, 8}},
            {{0, 4}, {2, 8}, {7, 11}},
            {{1, 8}, {3, 7}, {5, 4}, {8, 2}},
            {{2, 7}, {4, 9}, {5, 14}},
            {{3, 9}, {5, 10}},
            {{2, 4}, {3, 14}, {4, 10}, {6, 2}},
            {{5, 2}, {7, 1}, {8, 6}},
            {{0, 8}, {1, 11}, {6, 1}, {8, 7}},
            {{2, 2}, {6, 6}, {7, 7}}
        };
        auto result = delayAwareRouting(0, 8, 4, largeGraph);
        printRoutingResult(result);

    }
}

int main() {

    vector<vector<pair<int, int>>> smallGraph = {
        {{1, 1}, {2, 4}},
        {{0, 1}, {2, 2}, {3, 6}},
        {{0, 4}, {1, 2}, {3, 3}},
        {{1, 6}, {2, 3}}
    };

    auto result = delayAwareRouting(0, 3, 2, smallGraph);
    printRoutingResult(result);
    cout<<"\n\n"<<endl;
    testForDAR();
    
    return 0;
}
