//update the weight of a graph
#include "NetworkBase.h"
#include <iostream>
#include <nlohmann/json.hpp>
#include <string>
#include <sstream>

using json = nlohmann::json;
// 在 NetworkStructures.h 中定义的 Graph 类的成员函数实现

void Graph::addNode(const std::string& node_name, NodeType type) {
    adjacency_list[node_name] = std::vector<Link>();
    node_types[node_name] = type;
}

NodeType Graph::getNodeType(const std::string& node_name) const {
    auto it = node_types.find(node_name);
    if (it != node_types.end()) {
        return it->second;
    } else {
        // 在节点类型未找到时，可以抛出异常或返回默认值
        throw std::runtime_error("Node type not found for node: " + node_name);
        // 或者返回一个特定的默认值，例如 NodeType::Terminal
    }
}


bool Graph::nodeExists(const std::string& node_name) const {
    return adjacency_list.find(node_name) != adjacency_list.end();
}



Link Graph::getLink(const std::string& source_node, const std::string& target_node) const {
    if (adjacency_list.find(source_node) != adjacency_list.end()) {
        for (const auto& link : adjacency_list.at(source_node)) {
            if (link.target_node == target_node) {
                return link;
            }
        }
    }
    return Link("", 0, 0,0); // 返回一个空的 Link 对象作为默认值
}

void Graph::updateLinkWeight(const std::string& source_node, const std::string& target_node, int new_weight) {
    for (auto& link : adjacency_list[source_node]) {
        if (link.target_node == target_node) {
            link.link_weight = new_weight;
            break;
        }
    }
}

void Graph::addInterfaceToDeviceMapping(const std::string& interface_name, const std::string& device_name) {
    interface_to_device[interface_name] = device_name;
}

void Graph::printGraph() const {
    for (const auto& node : adjacency_list) {
        std::cout << "Node " << node.first << " has links to: \n";
        for (const auto& link : node.second) {
            std::cout << " - " << link.target_node << " (Weight: " << link.link_weight << ", Rate: " << link.link_rate <<", Length: " << link.link_length<< ")\n";
        }
        if (node.second.empty()) {
            std::cout << " [No links]\n";
        }
    }
}

void Graph::printGraphWithInterfaces() const {
    for (const auto& interface_pair : interface_to_device) {
        const std::string& interface_name = interface_pair.first;
        const std::string& device_name = interface_pair.second;

        std::cout << "Interface " << interface_name << " on device " << device_name << " has links to:\n";

        if (adjacency_list.find(device_name) != adjacency_list.end()) {
            for (const auto& link : adjacency_list.at(device_name)) {
                std::cout << " - " << link.target_node << " (Weight: " << link.link_weight << ", Rate: " << link.link_rate << ")\n";
            }
        } else {
            std::cout << " [No links]\n";
        }
    }
}


// 计算链路利用率的函数
double calBandwidthUtilization(const FlowSpec& flowSpec, const Link& link) {
    //return (8.0 * flowSpec.flow_length) / (1e6 * link.link_rate * flowSpec.flow_interval);
    return (8.0 * flowSpec.flow_length) / (link.link_rate * flowSpec.flow_interval)*1e5;  //Unit of interval is nanosecond
}

// 更新 Graph 的函数
void updateGraph(Graph& graph, const FlowPath& flowPath, double weight) {
    for (size_t i = 0; i < flowPath.path_nodes.size() - 1; ++i) {
        graph.updateLinkWeight(flowPath.path_nodes[i], flowPath.path_nodes[i + 1], static_cast<int>(weight));
    }
}

int convertRateToMbps(const std::string& rateStr) {
    double rate;
    std::stringstream(rateStr) >> rate;
    return static_cast<int>(rate / 1e6);
}



std::string extractDeviceName(const std::string& interfaceName) {
    auto pos = interfaceName.find('.');
    return (pos != std::string::npos) ? interfaceName.substr(0, pos) : interfaceName;
}

int main() {
    // 创建 Graph 实例
    Graph networkGraph;

    // 定义接口名称
    std::string terminal1Interface = "Terminal1.eth0";
    std::string terminal2Interface = "Terminal2.eth0";
    std::string switch1Interface1 = "Switch1.eth1";
    std::string switch1Interface2 = "Switch1.eth2";

    // 添加接口到设备的映射
    networkGraph.addInterfaceToDeviceMapping(terminal1Interface, "Terminal1");
    networkGraph.addInterfaceToDeviceMapping(terminal2Interface, "Terminal2");
    networkGraph.addInterfaceToDeviceMapping(switch1Interface1, "Switch1");
    networkGraph.addInterfaceToDeviceMapping(switch1Interface2, "Switch1");

    // 添加节点
    networkGraph.addNode("Terminal1", NodeType::Terminal);
    networkGraph.addNode("Terminal2", NodeType::Terminal);
    networkGraph.addNode("Switch1", NodeType::Switch);

    // 添加链接
    networkGraph.addUndirectedLink(terminal1Interface, switch1Interface1, 10, 1000, 100);
    networkGraph.addUndirectedLink(switch1Interface2, terminal2Interface, 10, 1000, 100);

    // 更新节点索引映射和邻接表
    networkGraph.updateNodeIndexMap();
    networkGraph.updateAdjList();

    // 打印网络拓扑
    networkGraph.printGraph();

    // 打印邻接表
    std::cout << "\nAdjacency List Representation:\n";
    //networkGraph.printAdjacencyList();

    std::vector<std::vector<std::pair<int, int>>> graph = networkGraph.toAdjacencyList();

    // 打印邻接表
    for (const auto& row : graph) {
        for (const auto& pair : row) {
            std::cout << "{" << pair.first << ", " << pair.second << "}, ";
        }
        std::cout << std::endl;
    }
    networkGraph.printNodeIndexMap();

    // 创建 FlowSpec 实例
    std::vector<FlowSpec> flows;
    flows.push_back(FlowSpec("Flow1", 100, 20, 5));
    flows.push_back(FlowSpec("Flow2", 200, 15, 3));
    flows.push_back(FlowSpec("Flow3", 150, 25, 7));

    // 打印流量信息
    std::cout << "\nFlow Details:" << std::endl;
    for (const auto& flow : flows) {
        std::cout << "Flow: " << flow.flow_name << ", Length: " << flow.flow_length 
                  << ", QoS: " << flow.flow_qos << ", Hop: " << flow.hop_toNow << std::endl;
    }

    return 0;
}
