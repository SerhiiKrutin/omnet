#ifndef JSONBASE_H_
#define JSONBASE_H_

std::string connectionsToJson(const std::string& input);



#endif /* CUSTOMMODULE_H_ */
