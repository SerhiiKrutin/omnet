#ifndef GETSUBNET_VEROPT_H
#define GETSUBNET_VEROPT_H

#include <iostream>
#include <map>
#include <vector>
#include <string>
#include <set>
#include <chrono>
#include <algorithm>

// 这里声明 getSubNets 函数和任何其他在 getSubnet-verOPT.cpp 中定义的函数
std::vector<std::string> findLongestCommonSubsequence(const std::vector<std::string>& a, const std::vector<std::string>& b);
std::vector<std::vector<std::string>> splitPath(const std::vector<std::string>& path, const std::set<std::string>& splitNodes);
std::map<std::vector<std::string>, std::set<std::string>> getSubNets(const std::map<std::string, std::vector<std::string>>& flowPaths);

#endif // GETSUBNET_VEROPT_H
