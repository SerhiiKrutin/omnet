#include "getSubnet-verOPT.h"


std::vector<std::string> findLongestCommonSubsequence(const std::vector<std::string>& a, const std::vector<std::string>& b) {
    int lenA = a.size();
    int lenB = b.size();
    std::vector<std::vector<int>> dp(lenA + 1, std::vector<int>(lenB + 1, 0));

    for (int i = 1; i <= lenA; ++i) {
        for (int j = 1; j <= lenB; ++j) {
            if (a[i - 1] == b[j - 1]) {
                dp[i][j] = dp[i - 1][j - 1] + 1;
            } else {
                dp[i][j] = std::max(dp[i - 1][j], dp[i][j - 1]);
            }
        }
    }

    std::vector<std::string> lcs;
    int i = lenA, j = lenB;
    while (i > 0 && j > 0) {
        if (a[i - 1] == b[j - 1]) {
            lcs.push_back(a[i - 1]);
            --i;
            --j;
        } else if (dp[i - 1][j] > dp[i][j - 1]) {
            --i;
        } else {
            --j;
        }
    }

    std::reverse(lcs.begin(), lcs.end());
    return lcs;
}

std::vector<std::vector<std::string>> splitPath(const std::vector<std::string>& path, const std::set<std::string>& splitNodes) {
    std::vector<std::vector<std::string>> splitPaths;
    std::vector<std::string> currentPath;

    for (const auto& node : path) {
        currentPath.push_back(node);
        if (splitNodes.find(node) != splitNodes.end() && currentPath.size() > 1) {
            splitPaths.push_back(currentPath);
            currentPath.clear();
            currentPath.push_back(node);
        }
    }

    if (!currentPath.empty()) {
        splitPaths.push_back(currentPath);
    }

    return splitPaths;
}

std::map<std::vector<std::string>, std::set<std::string>> getSubNets(const std::map<std::string, std::vector<std::string>>& flowPaths) {
    std::map<std::vector<std::string>, std::set<std::string>> subNets;
    std::set<std::string> allSplitNodes;

    for (auto it1 = flowPaths.begin(); it1 != flowPaths.end(); ++it1) {
        for (auto it2 = std::next(it1); it2 != flowPaths.end(); ++it2) {
            std::vector<std::string> lcs = findLongestCommonSubsequence(it1->second, it2->second);
            if (lcs.size() > 1) {
                allSplitNodes.insert(lcs.begin() + 1, lcs.end());
            }
        }
    }

    for (const auto& flow : flowPaths) {
        auto splitPaths = splitPath(flow.second, allSplitNodes);
        for (const auto& spath : splitPaths) {
            subNets[spath].insert(flow.first);
        }
    }

    return subNets;
}

int main() {
    std::map<std::string, std::vector<std::string>> flowPaths = {
        {"flow1", {"sw1", "sw2", "sw3", "sw4"}},
        {"flow2", {"sw1", "sw2", "sw5", "sw6"}},
        {"flow5", {"sw1", "sw7"}},
        {"flow9", {"sw1", "sw2", "sw8"}},
        {"flow25", {"sw1", "sw2", "sw5", "sw9"}}
    };

    auto start = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < 100000; ++i) {
        auto subNets = getSubNets(flowPaths);
    }

    auto end = std::chrono::high_resolution_clock::now();

    // 转换时间差为微秒并计算平均时间
    std::chrono::duration<double, std::micro> elapsed = (end - start) / 100000;

    std::cout << "Average elapsed time per iteration: " << elapsed.count() << " µs\n";

    return 0;
}



