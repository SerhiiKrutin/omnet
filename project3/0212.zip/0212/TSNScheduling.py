from collections import defaultdict
from heapq import heapify,heappop,nlargest
from math import ceil, floor,pow,log
from sys import exit,argv
import time
from os import _exit
from os.path import exists

userDefined = True # if false, default value: frame size is 1500, link length is 100, link speed is 1000
allocationTS,egressFlowset, egressTimeset,Flowset, Timeset,subNetwork = defaultdict(list),defaultdict(list),defaultdict(list),defaultdict(list),defaultdict(list), defaultdict(list)
TStoflow=defaultdict(list)
GCL=defaultdict(list)
FlowIndex = defaultdict(list)

talkerResults = defaultdict(list) # 09-13 add record flow info (flowId, FMTI) that transmitted between same src and same dst
flowSrcDst = defaultdict(list) # 09-13 to record flow src end-station and dst end-station. {flowId:[src,dst]}
def TopologyPartition(ShortestPath, SrcDst,Pos,Qos,reverse_lookup,flowIdRecord):
    #flowid = qos +1
    # hopcount = startIndex or i
    #output: subNetwork = {(SP):(flowid, qos, hopcount)}    SP = shortest path without any branches, hopcount: to the first element in SP
    #example: {(1,9):(1,2)} the hop-count from src_node of flow1 to sw1 is 2.
    #reverse_lookup=dict()
    #0313-2023: Output: (sw_n,sw_m):(qos,flow_index,hop_count, flow_id) flow1's flow_index is 1;
    lenLista = len(ShortestPath)

    flowId = flowIdRecord[Pos]          # add 09-13
    srcEs = ShortestPath[0]             # add 09-13
    dstEs = ShortestPath[lenLista-1]    # add 09-13
 
    flowSrcDst[flowId].append(srcEs)    # add 09-13
    flowSrcDst[flowId].append(dstEs)    # add 09-13
    if lenLista ==2:

        #subNetwork[tuple(ShortestPath)].append((Qos[Pos],Pos+1,1))    # delete 09-12
        subNetwork[tuple(ShortestPath)].append((Qos[Pos],Pos+1,1,flowId))    # delete 09-12
 
        return subNetwork
    #thinSP = ShortestPath[1:lenLista-1]
    
    startIndex = 0
    lenDictb = len(reverse_lookup)
    for i, x in enumerate(ShortestPath):
        #print("Shortest is {}, index is {}, X is {}".format(ShortestPath,i,x))
        if i == 0:
            continue
        if x in reverse_lookup:
            if lenLista == i+1 - startIndex:
                qos = Qos[Pos]
            else:
                qos = Qos[Pos] * (i+1 - startIndex) // (lenLista + 1)
            subNetwork[tuple(ShortestPath[startIndex:i+1])].append((qos,Pos+1,startIndex+1,flowId))   # add 09-12
        
            #startIndex += i   # 04-26 
            startIndex = i # 04-26 
            lenDictb -=1
        if lenDictb == 0 and i < lenLista:
            if lenLista == lenLista - i:
                qos = Qos[Pos]
            else:          
                qos = Qos[Pos] * (lenLista - i) // (lenLista + 1)
            subNetwork[tuple(ShortestPath[i:lenLista])].append((qos,Pos+1,i+1,flowId))  # add 09-12
            
            break
    #print("(3,6) subnetwork is ",subNetwork)
    return subNetwork

def DelayCalculation(HopCnt):
    FrameLength = 1500 # this is constrainted by 's algorithm
    LinkSpeed = 1000
    LinkLength =100
    if userDefined:
        d_trans =  (FrameLength + 30)*8000 // LinkSpeed  # unit is nanao-second
        IFG = 96000 // LinkSpeed  # unit is nanao-second
        LenTSinTCI = d_trans + IFG
        # add a function to calculate pre_e2e
        d_proc = 8000 # unit is nanao-second
        d_prop = LinkLength*10 // 2 # unit is nanao-second
        arriveTSatCurrentSW = HopCnt * ( d_proc + d_prop + d_trans )  
        return LenTSinTCI,arriveTSatCurrentSW
    else:
        return 12336,HopCnt*20740

def assignToEgress(Flowset,Timeset):
    
    for sn,flow in Flowset.items():

        lensn = len(sn)
        if lensn == 2:
            for f in flow:
                egressFlowset[sn].append(f)
            egressTimeset[sn].append(Timeset[sn][0])

            
        else:
            numEgress = lensn - 1
            egress = [0]*numEgress
            for cnt in range(lensn-1):
                egress= (sn[cnt],sn[cnt+1])
                for f in flow:   # 0416 revised 
                    hop, id, qos, k, tsai, flowId = f
                    hop += cnt
                    egressFlowset[egress].append([hop, id, qos, k, tsai,flowId])  # flowId is added 09-13
                egressTimeset[egress].append(Timeset[sn][0])

def flowVarsForEgress(Flowset):
    
    for sn,flow in Flowset.items():
       
        lensn = len(sn)
        if lensn == 2:
            for f in flow:
                egressFlowset[sn].append(f[5])
        else:
            numEgress = lensn - 1
            egress = [0]*numEgress
            for cnt in range(lensn-1):
                egress= (sn[cnt],sn[cnt+1])
                for f in flow:   # 0416 revised 
                    egressFlowset[sn].append(f[5])


def step1andstep2_CalculateRelatedParameters(subnetwork):
    
    numFlow = 0
    #print("debug 0",subnetwork)
    for sn,flow in subnetwork.items():

        heapify(flow)     #convert flow list to flow heap
        #flow[0] is the first message
        tdi = flow[0][0] # get the smalleset qos to be TDI
        #tsTCI,atTS = DelayCalculation(flow[0][2])  # by default link speed is set to 1000 Mbps, length is set to 100 meters.
        #ntci1 = atTS - 12240 # according to equation (7), GB = 12240, which is eaqual to the transmission duration of the maximum-size frame on the 1000-Mbps link.
        lenFlow = len(flow)
        atstcd = 0 # the average number of time slot allocated in TCI
        #print("debug 1",flow)
        while flow:
            #print("debug",flow)
            qos, id, hop,flowId = heappop(flow)
            if numFlow <= id:
                numFlow = id 
            x = qos // tdi  # floor function
            k = int(pow(2,floor(log(x,2))))
            tsai = k * tdi # tdi is eaqual to tsai1 
            atstcd += tdi / tsai
            
            flowset = [hop, id, qos, k, tsai, flowId]  # after 04-15   delete 09-12  "id" in this array means the flow index
                  
            Flowset[sn].append(flowset)
            if not flow:  # all flows are traversed
                tstcd = ceil(atstcd)
                tci = tstcd * 12336
                Timeset[sn].append([tsai,tdi,tstcd,tci]) #at this time tsai is the max(tsai), thus is eqaual to the hyper period
    
    # Flowset contains all flow information, Timeset conatins all time-related information for an egress
 
    assignToEgress(Flowset,Timeset)  # Sub-network might contain many switches, this function breaks subNetwork to Two adjacancy switch set. 09-13 add comments
    FMTItalker = [1] * numFlow 
    return FMTItalker 
    #return Flowset,Timeset

def step3_AllocateFlowtoSlot(Flow,Time,FMTItalker,gclname):

 
    for egress,flow in Flow.items():
       # print("current egress is {}, FLow 23 is {}".format(egress,Flow[(2,3)]))

        hyperPeriod,tdi,tstcd,tci= Time[egress][0] # need to be updated 
        flagFirstMsg = True
        numtdi = hyperPeriod // tdi
        avaliableNumTS = tstcd * numtdi
        avaliableTS = avaliableNumTS * [None]
        
        #allocationTS[egress].append((hyperPeriod,tdi,tstcd))  # add by  04-17  #  delete 09-13 
        conflict = False

        #sortedlist = sorted(flow,key = lambda x: -x[0])
        # this condition guarantee that a flow with a bigger hop-count be the first message.
        # two flows, f3=1, f5 hop=5, f5 arrives sw at 5*Delay, 
        # if f5 is not first message, f3 will be the first one, the start-time-instant of TCI is around 2*Delay,
        #then f5 cannot arrive the sw whne the corresponding slot is ready.
        sortedlist = sorted(flow,key = lambda x: x[2])
        for i in sortedlist:
            hop, id, qos, k, tsai, flowId = i   # modify 09-12 "flowId" is added
            #requireNumTS = hyperPeriod // tsai   --> delete 09-13
            requireNumTS = qos // tsai  # --> revise to qos
            allocationOffset = tstcd * k  # k is eqaul to tsai // tdi
            
            print("\nFlow is {}, tsai is {}, tdi is {}, hyperiod is {}, qos is {}, requireNumTS is {}, allocationOffset is {}, k is {}"\
                .format(flowId,tsai,tdi,hyperPeriod,qos,requireNumTS,allocationOffset,k))
            try:
                firstAvaliableTS = int(avaliableTS.index(None))
            except BaseException:
                print("debug: avaliableTS is {}, avaliableNumTS is {}".format(avaliableTS,avaliableNumTS))
                return 

            
            indexFlow = id -1
            fmtitalker=0
            fmtitalkerFlg = FMTItalker[indexFlow]
          
            #conflict of fmtitalker occurs.
            if fmtitalkerFlg < 0:
                conflict = True
                firstAvaliableTS = firstAvaliableTS-fmtitalkerFlg # move backward -fmtitalkerFlg slot
                fmtitalkerFlg = 1
            
            stdin = firstAvaliableTS // tstcd
            ssn = firstAvaliableTS % tstcd

            if flagFirstMsg:

                #  04-16, the following paramters are related the first flow transmitted in the network
                # ntci1 = FMTISW - GB
                # FMTISW = fmtitalker + arrivalTS = fmtitalker + hop-count * 20.74 (process_delay 8 + propogation delay 0.5 + Transmission dely 12.24)
                # Since only first msg is useful to determine the start-TS of first slot, fmtitalker is equal to 0

                #FMTISW = fmtitalker+ (ntci1 + 12240)*hop # Constrained by Qbv standard, 12240 is the duration of GB, guard band.
                #FMTISW = fmtitalker + 20740 * hop  # comment by  04-17
                
                FMTISW = 20740 * hop  # 04-17  the start-instance of first TSN msg is eaqual to 0.
                if conflict:
                    FMTISW = 20740 * hop + stdin * tdi + ssn * 12336 # if transmission conflict occurs, the first messages shoule be delayed to transmite.
                ntci1 = 20740*hop - 12240
                ntci2 = tdi - ntci1 - tci - 12240
                #ntci2 = tdi - tci - ntci1 - 12240 # 12240 is the length of Guard Band
                if ntci2 < 0:
                    print("Error, Break the stable condition, please reduce TSN traffic in sub-network",egress)
                    print("Dump: flow id is {}, qos is {}, tdi is {}, tci is {}, ntci1 is {}, ntci2 is {}".format(id,qos,tdi,tci,ntci1,ntci2))
                    return ["error"],{},{}

                    #exit(1)
                else:  
                    flagFirstMsg = False
                    #generate GCL process
                    if egress not in GCL.keys():
                          
                        GenerateGCLs(FMTISW,tdi,numtdi,tstcd,egress,gclname)      
            
            else: 
                #revise 06-10
                maxdelay = hop*20740 
                FMTISW = stdin * tdi + ntci1 + 12240 + ssn * 12336
               # print("before while",FMTISW,maxdelay)
                while maxdelay > FMTISW:
                    firstAvaliableTS=firstAvaliableTS+1
                    if firstAvaliableTS >= avaliableNumTS:
                        print("error there are no enough time slots")
                        print("egress is {}, flow is {}, firstAvaTS is {}, avanumTS is{}".format(egress,id,firstAvaliableTS,avaliableNumTS))
                        return ["error"],{},{}
                        #exit(1)
                    stdin = firstAvaliableTS // tstcd
                    ssn = firstAvaliableTS % tstcd
                    FMTISW = stdin * tdi + ntci1 + 12240 + ssn * 12336
                    
            #TStoflow[(egress)][id] = firstAvaliableTS
            if fmtitalkerFlg == 1:
                fmtitalker = FMTISW - hop*20740 
                #print("flow is {}, fmtitalker is {}, fmtiSW is {}".format(id,fmtitalker,FMTISW))
                if fmtitalker < 0 :
                    print("error occurs egress is {}, flow is {}, fmtisw is {} hop is {},".format(egress,id,FMTISW,hop))
                FMTItalker[indexFlow] = fmtitalker  # Constrained by 's algorithm, 12336 is the transmission duration of maximum-size TSN frame
                #talkerFlowId[indexFlow] = flowId  # Add 09-12 
                talkerResults[egress].append([fmtitalker,flowId])  # [src,dst]

            # the following codes are used for debug, whithout the below information, GCL can be caclulated successfully.
            allocationCNT = 0
            while allocationCNT < requireNumTS:
                allocationCNT += 1
                if firstAvaliableTS >= len(avaliableTS):
                    print("there is no enough time-slot for flow {}, in egress {}".format(id,egress))
                    #exit(1)
                    continue
                avaliableTS[firstAvaliableTS] = id
                allocationTS[egress].append([flowId,firstAvaliableTS,tstcd])     # modify 09-13  structure: {egress:[[flowId, occupyTS, numOfTSinTCI]]}
                firstAvaliableTS += allocationOffset

    return FMTItalker,allocationTS,talkerResults


def GenerateGCLs(ArrivedTimeInstance,tdi,numTDI,tstcd,egress,gclname):
    

    GB_interval = 12240
    GateState_TSN = "10000000"
    GateState_BE =  "01111111"
    GateState_GB = "00000000"


    GCL_len = numTDI * 3 
    TSN_interval = tstcd * 12336
    BE_interval = tdi - TSN_interval - GB_interval

    strTSN_interval = str(TSN_interval)
    strGB_interval = str(GB_interval)
    strBE_interval = str(BE_interval)
    #firtArrivedTSNflow = 
    first_interval = ArrivedTimeInstance - GB_interval
    strfirst_interval = str(first_interval)

    last_interval = BE_interval - first_interval
    strlast_interval = str(last_interval)

    first_entry = GateState_BE + "    " + strfirst_interval + "\n"

    last_entries = \
                    GateState_GB + "    " + strGB_interval + "\n" + \
                    GateState_TSN + "    " + strTSN_interval + "\n" + \
                    GateState_BE + "    " + strlast_interval + "\n"

    base_middle_entries = \
                    GateState_GB + "    " + strGB_interval + "\n" + \
                    GateState_TSN + "    " + strTSN_interval + "\n" + \
                    GateState_BE + "    " + strBE_interval + "\n"
    middle_entries = base_middle_entries * (int(numTDI) - 1)
    
    hyperperiod = tdi * numTDI
    version = "Current GCL is used for the egress" + str(egress) + "\n"+"HyperPeriod  " + str(hyperperiod)
    # strGCL = version +"\n" +\
    #             first_entry + middle_entries + last_entries
    strGCL = "hyperPeriod    " +str(hyperperiod)+ "\n" \
            + "numOfEntries    " + str(GCL_len) + "\n" \
            + first_entry + middle_entries + last_entries

    GCL[egress].append(strGCL)
    

def CheckConflict(FMTITalker,ES_Flow,cnt):
    if len(FMTITalker) != len(ES_Flow):
        print("CheckConflict, line 310,Flow number is different, please check the inputs")
        print("len of FMTITalker is {}, len of ES_Flow is {}".format(len(FMTITalker), len(ES_Flow)))
        exit(1)
    check = []
    for pos in range(len(ES_Flow)):
        checkValue = FMTITalker[pos]*ES_Flow[pos]
        #print("debug~~",checkValue)
        
        if check.count(checkValue) !=0:

            if  ES_Flow[pos] == ES_Flow[check.index(checkValue)]:
                #print("Transmission conflict occurs, flow {} and flow {} has the same FMTI".format(check.index(checkValue)+1,pos+1))
                #print(FMTITalker)
                FMTITalker[pos] = cnt * -1

                return False, FMTITalker
            else:
                #print("Value same but from different source node~")
                check.append(checkValue)
            #note that a while(1)
        else:
            check.append(checkValue)
            #print("NO Transmission conflict occurs")
    return True, FMTITalker


def runBAS(flowIdRecord,routes,srcdst,esflow,qos_ns,gclname):
  

    clearVars()
    pos = 0
    reverse_lookup = {x:i for i, x in enumerate(srcdst)} # make a Dict. to contain value and index.
    print("\n\n",reverse_lookup)
    #exit(21)
    for sp in routes:
        #print("sp is ",sp)
        subN = TopologyPartition(sp,srcdst,pos,qos_ns,reverse_lookup,flowIdRecord)
        #print("subN",subN)

        pos+=1
    
 #   subN = {(1, 2): [(100000, 1, 1, 'aa:11:00:00:01:01-aa:11:00:00:01:03-20230305004108'), (100000, 2, 1,'aa:11:00:00:01:02-aa:11:00:00:01:05-20230305004127')], (2, 3): [(100000, 2, 2, 'aa:11:00:00:01:02-aa:11:00:00:01:05-20230305004127'), (100000, 3, 1, 'aa:11:00:00:01:03-aa:11:00:00:01:07-20230305004144'), (200000, 4, 1, 'aa:11:00:00:01:04-aa:11:00:00:01:10-20230305004202')], (3, 4): [(100000, 3, 2, 'aa:11:00:00:01:03-aa:11:00:00:01:07-20230305004144'), (800000, 6, 1, 'aa:11:00:00:01:06-aa:11:00:00:01:08-20230305004235')], (3, 5): [(400000, 5, 1, 'aa:11:00:00:01:05-aa:11:00:00:01:09-20230305004216'), (800000, 6, 2, 'aa:11:00:00:01:06-aa:11:00:00:01:08-20230305004235')]}
    FMTItalker = step1andstep2_CalculateRelatedParameters(subN) 
 
    schedulingFlag = False
    #FMTItalker,allocationTS = step3_AllocateFlowtoSlot(Flowset,Timeset,FMTItalker,gclname)
    cnt = 1 
    while schedulingFlag == False:
       
        #print("flowset is {}, timeset is {}".format(Flowset[(30,12)],Timeset[(30,12)]))

        FMTItalker,allocationTS,talkerResults = step3_AllocateFlowtoSlot(egressFlowset,egressTimeset,FMTItalker,gclname)
        #print("FMTItalker",FMTItalker)
      
        #print("allocationTS are ",allocationTS[(0,5)])
        #allocationTS.clear()
        if FMTItalker[0] == "error":
            return False,talkerResults,allocationTS 
        schedulingFlag, FMTItalker = CheckConflict(FMTItalker,esflow,cnt)
        cnt+=1
    flowVarsForEgress(Flowset)          #  Add 09-12
    return True,talkerResults,allocationTS      #add 09-13

def clearVars():
    flowSrcDst.clear()          # add 09-13
    talkerResults.clear()       # add 09-13
    allocationTS.clear()
    egressFlowset.clear()
    egressTimeset.clear()
    Flowset.clear()
    Timeset.clear()
    subNetwork.clear()
    TStoflow.clear()
    GCL.clear()
def convertStrtoList(strdata,flag):
    strele=""
    element=[]
    if flag == 1:
        for i in strdata:
            
            if i != "[" and i != "]" and i != ",":
                strele=strele+i
            if i == ",":
                if strele != "":
                    element.append(int(strele))
                    strele=""
            if i == "]":
                element.append(int(strele))

        
    elif flag ==2:
        subelement=[]
        for i in strdata:
            #print("i = ",i)
            if i != "[" and i != "]" and i != ",":
                strele=strele+i
            if i == ",":
                if strele != "":
                    subelement.append(int(strele))
                    strele=""   
            if i == "]":
                if strele != "":
                    subelement.append(int(strele))
                    strele="" 
                    element.append(subelement)
                    #print(subelement)
                    subelement=[]
    return element

    #print("element is {}, type is {}".format(element,type(element)))

#print("in Python")
if __name__=="__main__":

    webflowIdRecord = ['26:5f:14:7b:2a:0a-aa:00:00:00:00:12-01', 'aa:00:00:00:00:11-26:5f:14:7b:2a:0a-01', 'aa:00:00:00:00:11-aa:00:00:00:00:12-01'] 
    webroutes = [[1, 2], [3, 1], [3, 1, 2]]
    webSrcDst = [3, 1, 2]
    webflowSrcMap = [-1, -2, -2]
    webqos = [2000000, 2000000, 2000000]
    #flagl,egressFlowset,talkerResults = runBAS(flowIdRecord,routes,testNodeset,esflow,qos_ns,"gcl") #flowIdRecord,routes,srcdst,esflow,qos_ns,gclname
    flagl,egressFlowset,talkerResults = runBAS(webflowIdRecord,webroutes,webSrcDst,webflowSrcMap,webqos,"gcl0913") #flowIdRecord,routes,srcdst,esflow,qos_ns,gclname
    #print("egressFlowset",egressFlowset)
    print(GCL)
  