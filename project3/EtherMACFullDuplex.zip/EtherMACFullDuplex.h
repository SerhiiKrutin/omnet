//
// Copyright (C) 2006 Levente Meszaros
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, see <http://www.gnu.org/licenses/>.
//

#ifndef __INET_ETHERMACFULLDUPLEX_H
#define __INET_ETHERMACFULLDUPLEX_H

#include "inet/common/INETDefs.h"

#include "inet/linklayer/ethernet/EtherMACBase.h"

namespace inet {

/**
 * A simplified version of EtherMAC. Since modern Ethernets typically
 * operate over duplex links where's no contention, the original CSMA/CD
 * algorithm is no longer needed. This simplified implementation doesn't
 * contain CSMA/CD, frames are just simply queued up and sent out one by one.
 */
class INET_API EtherMACFullDuplex : public EtherMACBase
{
  public:
    EtherMACFullDuplex();

  protected:
    virtual int numInitStages() const override { return NUM_INIT_STAGES; }
    virtual void initialize(int stage) override;
    virtual void initializeStatistics() override;
    virtual void initializeFlags() override;
    virtual void handleMessage(cMessage *msg) override;

    // finish
    virtual void finish() override;

    // event handlers
    virtual void handleEndIFGPeriod();
    virtual void handleEndTxPeriod();
    virtual void handleEndPausePeriod();
    virtual void handleSelfMessage(cMessage *msg);

    // helpers
    virtual void startFrameTransmission();
    virtual void startQFramesTransmission();
    virtual void IDLEstartQFramesTransmission();



    virtual void changeSW1GateState();
    virtual void OperateGateState(int flag,int stage);
    virtual void startTSNFrameTransmission(EtherFrame *tsnframe);



    virtual void DynamicReadFile(const char *filename);
    virtual void CacheTraffic(EtherFrame * Curframe);

    virtual void processFrameFromUpperLayer(EtherFrame *frame);
    virtual void processMsgFromNetwork(cPacket *pk);
    virtual void processReceivedDataFrame(EtherFrame *frame);
    virtual void processPauseCommand(int pauseUnits);
    virtual void scheduleEndIFGPeriod();
    virtual void scheduleEndPausePeriod(int pauseUnits);
    virtual void beginSendFrames();

    // statistics
    simtime_t totalSuccessfulRxTime;    // total duration of successful transmissions on channel

    cQueue TSNCache;
    cQueue OtherCache;


    int currentStateSW1 = 0;

    simsignal_t recordDelay;
    simsignal_t recordCount;
    simsignal_t recordSend;
    simsignal_t recordReceive;


    simsignal_t Re2eflow1;
    simsignal_t Re2eflow2;
    simsignal_t Re2eflow3;
    simsignal_t Re2eflow4;
    simsignal_t Re2eflow5;
    simsignal_t Re2eflow6;
    simsignal_t Re2eflow7;
    simsignal_t Re2eflow8;
    simsignal_t Re2eflow9;
    simsignal_t Re2eflow10;
    simsignal_t Re2eflow11;
    simsignal_t Re2eflow12;
    simsignal_t Re2eflow13;
    simsignal_t Re2eflow14;
    simsignal_t Re2eflow15;
    simsignal_t Re2eflow16;
    simsignal_t Re2eflow17;
    simsignal_t Re2eflow18;
    simsignal_t Re2eflow19;
    simsignal_t Re2eflow20;
    simsignal_t Re2eflow21;
    simsignal_t Re2eflow22;
    simsignal_t Re2eflow23;
    simsignal_t Re2eflow24;
    simsignal_t Re2eflow25;
    simsignal_t Re2eflow26;
    simsignal_t Re2eflow27;
    simsignal_t Re2eflow28;
    simsignal_t Re2eflow29;
    simsignal_t Re2eflow30;
    simsignal_t Re2eflow31;
    simsignal_t Re2eflow32;
    simsignal_t Re2eflow33;
    simsignal_t Re2eflow34;
    simsignal_t Re2eflow35;
    simsignal_t Re2eflow36;
    simsignal_t Re2eflow37;
    simsignal_t Re2eflow38;




    std::string currentDoorState;
    std::string curnode;
    std::string CurMAC;
    EtherFrame * cacheframe =nullptr;

    const char *module =NULL;
    const char *module1 =NULL;
    const char *nowmacaddress =NULL;


    //2018.06.18  15:41

     char* configlist[100][3];
     int currentline = 0;

};

} // namespace inet

#endif // ifndef __INET_ETHERMACFULLDUPLEX_H

