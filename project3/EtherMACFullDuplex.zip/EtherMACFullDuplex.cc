//
// Copyright (C) 2006 Levente Meszaros
// Copyright (C) 2011 Zoltan Bojthe
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this program; if not, see <http://www.gnu.org/licenses/>.
//

#include "inet/linklayer/ethernet/EtherMACFullDuplex.h"

#include "inet/common/queue/IPassiveQueue.h"
#include "inet/common/NotifierConsts.h"
#include "inet/linklayer/ethernet/EtherFrame.h"
#include "inet/networklayer/common/InterfaceEntry.h"
#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <typeinfo>

#define MAXLINE 100

namespace inet {

// TODO: refactor using a statehine that is present in a single function
// TODO: this helps understanding what interactions are there and how they affect the state

Define_Module(EtherMACFullDuplex);

EtherMACFullDuplex::EtherMACFullDuplex()
{
}


simsignal_t  ST_markedTSNflow1;
simsignal_t  ST_markedTSNflow2;
//1111-p0-declare-end

void EtherMACFullDuplex::initialize(int stage)
{
    EtherMACBase::initialize(stage);

    if (stage == INITSTAGE_LOCAL) {
        recordDelay=registerSignal("recvDelay");
        recordCount=registerSignal("packetNum");
        recordSend = registerSignal("Asendtime");
        recordReceive =registerSignal("AReceivedtime");


        //1111-p1-ini-start
//2023-03-14 12:38:52
ST_markedTSNflow1 = registerSignal("markedTSNflow1");
ST_markedTSNflow2 = registerSignal("markedTSNflow2");
//1111-p1-ini-end



        Re2eflow37 = registerSignal("e2eflow37");
        Re2eflow38 = registerSignal("e2eflow38");


        Re2eflow1 = registerSignal("e2eflow1"); Re2eflow2 = registerSignal("e2eflow2");
        Re2eflow3 = registerSignal("e2eflow3"); Re2eflow4 = registerSignal("e2eflow4");
        Re2eflow5 = registerSignal("e2eflow5"); Re2eflow6 = registerSignal("e2eflow6");
        Re2eflow7 = registerSignal("e2eflow7"); Re2eflow8 = registerSignal("e2eflow8");
        Re2eflow9 = registerSignal("e2eflow9"); Re2eflow10 = registerSignal("e2eflow10");

        Re2eflow11 = registerSignal("e2eflow11"); Re2eflow12 = registerSignal("e2eflow12");
        Re2eflow13 = registerSignal("e2eflow13"); Re2eflow14 = registerSignal("e2eflow14");
        Re2eflow15 = registerSignal("e2eflow15"); Re2eflow16 = registerSignal("e2eflow16");
        Re2eflow17 = registerSignal("e2eflow17"); Re2eflow18 = registerSignal("e2eflow18");
        Re2eflow19 = registerSignal("e2eflow19"); Re2eflow20 = registerSignal("e2eflow20");
        Re2eflow21 = registerSignal("e2eflow21"); Re2eflow22 = registerSignal("e2eflow22");
        Re2eflow23 = registerSignal("e2eflow23"); Re2eflow24 = registerSignal("e2eflow24");
        Re2eflow25 = registerSignal("e2eflow25"); Re2eflow26 = registerSignal("e2eflow26");
        Re2eflow27 = registerSignal("e2eflow27"); Re2eflow28 = registerSignal("e2eflow28");
        Re2eflow29 = registerSignal("e2eflow29"); Re2eflow30 = registerSignal("e2eflow30");
        Re2eflow31 = registerSignal("e2eflow31"); Re2eflow32 = registerSignal("e2eflow32");
        Re2eflow33 = registerSignal("e2eflow33"); Re2eflow34 = registerSignal("e2eflow34");
        Re2eflow35 = registerSignal("e2eflow35"); Re2eflow36 = registerSignal("e2eflow36");

        bool TSNswitch =par("TSNswitch");
       const char *GCL = par("GCL");
        if(GCL!="Nofile")
        {
            DynamicReadFile(GCL);
        }
        //2018.08.28
        currentDoorState=configlist[0][1];

        if(TSNswitch)    //2018.08.28
        {


            module = getParentModule()->getParentModule()->getName();
            double interval;
            interval = atof(configlist[0][2])/1000000.000000000;
            scheduleAt(simTime()+interval,changeGateMsgSW1);
        }

        if (!par("duplexMode").boolValue())
            throw cRuntimeError("Half duplex operation is not supported by EtherMACFullDuplex, use the EtherMAC module for that! (Please enable csmacdSupport on EthernetInterface)");
    }
    else if (stage == INITSTAGE_LINK_LAYER) {
        beginSendFrames();    //FIXME choose an another stage for it
    }
}

void EtherMACFullDuplex::initializeStatistics()
{
    EtherMACBase::initializeStatistics();

    // initialize statistics
    totalSuccessfulRxTime = 0.0;
}
void EtherMACFullDuplex::initializeFlags()
{
    EtherMACBase::initializeFlags();

    duplexMode = true;
    physInGate->setDeliverOnReceptionStart(false);
}
void EtherMACFullDuplex::handleMessage(cMessage *msg)
{
    if (!isOperational) {
        handleMessageWhenDown(msg);
        return;
    }

    if (channelsDiffer)
        readChannelParameters(true);

    if (msg->isSelfMessage())
        handleSelfMessage(msg);
    else if (msg->getArrivalGate() == upperLayerInGate){
        processFrameFromUpperLayer(check_and_cast<EtherFrame *>(msg));
    }
    else if (msg->getArrivalGate() == physInGate)
        processMsgFromNetwork(PK(msg));
    else
        throw cRuntimeError("Message received from unknown gate!");

    if (hasGUI())
        updateDisplayString();
}
void EtherMACFullDuplex::handleSelfMessage(cMessage *msg)
{
    EV_TRACE << "Self-message " << msg <<" received\n";

    if (msg == endTxMsg)
        handleEndTxPeriod();
    else if (msg == endIFGMsg)
        handleEndIFGPeriod();
    else if (msg == endPauseMsg)
        handleEndPausePeriod();

    else if(msg == changeGateMsgSW1)
        changeSW1GateState();

    else
        throw cRuntimeError("Unknown self message received!");
}
void EtherMACFullDuplex::changeSW1GateState(){


    currentStateSW1++;
    if(currentStateSW1 == currentline)
    {
        currentStateSW1 =0;
    }
    EV<<"CurrentStateSW1 =   "<<currentStateSW1<<endl;

    bool TSNswitch = par("TSNswitch");
    if(TSNswitch)
    {
        OperateGateState(1,currentStateSW1);
    }
    //2018.08.28
}

void EtherMACFullDuplex::OperateGateState(int flag,int line)
    {
        currentDoorState = configlist[line][1];
        double interval;
        interval = atof(configlist[line][2])/1000000.000000000;
        scheduleAt(simTime()+interval,changeGateMsgSW1);

        if(transmitState==TX_IDLE_STATE)
        {
            IDLEstartQFramesTransmission();
        }

    }
void EtherMACFullDuplex::IDLEstartQFramesTransmission(){
    EV<<"Now in the startQFrameTransmission! "<<endl;
   // if(transmitState!=TX_IDLE_STATE){EV<<"Quite 1, busy"<<endl; return;}
    if(currentDoorState=="11000000")

    {

        if(!TSNCache.isEmpty())
        {
            curTxFrame = (EtherFrame*)TSNCache.pop();
         //   startTSNFrameTransmission((EtherFrame*)TSNCache.pop());
            startTSNFrameTransmission(curTxFrame);
        }


     }

   if(currentDoorState=="00111111"){
        EV<<"Other Traffic mode"<<endl;
      // if(transmitState!=TX_IDLE_STATE){return;}
        if(!OtherCache.isEmpty())
        {
            curTxFrame = (EtherFrame*)OtherCache.pop();

              startTSNFrameTransmission(curTxFrame);

        }
        EV<<"Other finish" <<endl;

    }

   if(currentDoorState=="11111111")
   {

     //  startFrameTransmission();
       //0830
       if(!TSNCache.isEmpty()&&transmitState==TX_IDLE_STATE)
       {
           curTxFrame = (EtherFrame*)TSNCache.pop();
           startTSNFrameTransmission(curTxFrame);
       }
       if(!OtherCache.isEmpty()&&transmitState==TX_IDLE_STATE)
       {
           curTxFrame = (EtherFrame*)OtherCache.pop();
           startTSNFrameTransmission(curTxFrame);

       }

   }
   EV<<"After IDLEQ transmission TSN queue length = "<<endl<<TSNCache.info()<<endl;
   EV<<"After IDLEQ transmission Other queue length = "<<endl<<OtherCache.info()<<endl;

}

void EtherMACFullDuplex::startQFramesTransmission(){
    EV<<"Now in the startQFrameTransmission! "<<endl;
    if(transmitState!=TX_IDLE_STATE){EV<<"Quite 1, busy"<<endl; return;}
    if(currentDoorState=="11000000")

    {
        if(transmitState!=TX_IDLE_STATE){EV<<"TSN mode no idle"<<endl;return;}
        if(!TSNCache.isEmpty())
        {
            startTSNFrameTransmission((EtherFrame*)TSNCache.pop());

        }
     }

   if(currentDoorState=="00111111"){
        EV<<"Other Traffic mode"<<endl;
      // if(transmitState!=TX_IDLE_STATE){return;}
        if(!OtherCache.isEmpty())
        {
             if(transmitState!=TX_IDLE_STATE){ EV<<"1000 0001 no idle"<<endl;return;}
              startTSNFrameTransmission((EtherFrame*)OtherCache.pop());

        }
        EV<<"Other finish" <<endl;

    }

   if(currentDoorState=="11111111")
   {

       if(!TSNCache.isEmpty()&&transmitState==TX_IDLE_STATE)
            {
                curTxFrame = (EtherFrame*)TSNCache.pop();
                startTSNFrameTransmission(curTxFrame);
            }
            if(!OtherCache.isEmpty()&&transmitState==TX_IDLE_STATE)
            {
                curTxFrame = (EtherFrame*)OtherCache.pop();
                startTSNFrameTransmission(curTxFrame);

            }
   }


}
void EtherMACFullDuplex::startTSNFrameTransmission(EtherFrame * tsnframe)
{
   // if(transmitState!=TX_IDLE_STATE){return;}
    EtherFrame *frame = tsnframe->dup();
  //  EtherFrame *frame = tsnframe;
    if(frame != nullptr)
    {
        EtherPhyFrame *phyFrame = encapsulate(frame);
        send(phyFrame, physOutGate);
//        scheduleAt(transmissionChannel->getTransmissionFinishTime(), endTxMsg);

        transmitState = TRANSMITTING_STATE;
        emit(transmitStateSignal, TRANSMITTING_STATE);
    }
    scheduleAt(transmissionChannel->getTransmissionFinishTime(), endTxMsg);

}


void EtherMACFullDuplex::CacheTraffic(EtherFrame * Curframe)    //TO DO 2018.08.28 // 2020. 03.29 // 2021. 11-21
{


    if(Curframe == nullptr)
    {
        EV<<"CurFrame = null"<<endl;
        return;
    }
    //2020 03 28 start
    CurMAC = Curframe->getSrc().str().c_str();
    //CurMAC=CurMAC.substr(0,2);
    std::string sub_Cur_MAC = CurMAC.substr(0,5);
    EV<<"2021-11-21 CurFrame = "<<sub_Cur_MAC<<endl;
    int equal_flag = 99;
    equal_flag = strcmp(sub_Cur_MAC.c_str(),"00-00");
    EV<<"2021-11-21 equal_flag = "<<equal_flag<<endl;
    if((strcmp(sub_Cur_MAC.c_str(),"AA-AA")== 0))
    {
        EV<<"2021-11-21 TSN_Frame = "<<Curframe->getSrc().str().c_str()<<endl;
        TSNCache.insert(Curframe);
    }
    else{

        EV<<"2021-11-21 ETH Frame = "<<Curframe->getSrc().str().c_str()<<endl;

        OtherCache.insert(Curframe);

    }




    // 2020 03 28 end

}
void EtherMACFullDuplex::startFrameTransmission()
{
    long count = 0;

    ASSERT(curTxFrame);
    EV_DETAIL << "Transmitting a copy of frame " << curTxFrame << endl;

    EtherFrame *frame = curTxFrame->dup();    // note: we need to duplicate the frame because we emit a signal with it in endTxPeriod()
    if (frame->getSrc().isUnspecified())
        frame->setSrc(address);

    if (frame->getByteLength() < curEtherDescr->frameMinBytes)
        frame->setByteLength(curEtherDescr->frameMinBytes);     // extra padding

    // add preamble and SFD (Starting Frame Delimiter), then send out
    EtherPhyFrame *phyFrame = encapsulate(frame);

    // send
    EV_INFO << "Transmission of " << frame << " started.\n";
    send(phyFrame, physOutGate);

    scheduleAt(transmissionChannel->getTransmissionFinishTime(), endTxMsg);
    transmitState = TRANSMITTING_STATE;
    emit(transmitStateSignal, TRANSMITTING_STATE);

    bool record_tx = par("analysis_Txnum");
    if (record_tx)
    {
        emit(recordCount,count++);
    }

}


void EtherMACFullDuplex::processFrameFromUpperLayer(EtherFrame *frame)
{
    ASSERT(frame->getByteLength() >= MIN_ETHERNET_FRAME_BYTES);

    EV_INFO << "Received " << frame << " from upper layer." << endl;
    EV<<"Firstly, original upper layer address = "<<frame->getDest().str().c_str() <<endl;
    emit(packetReceivedFromUpperSignal, frame);

    if (frame->getDest().equals(address)) {
        throw cRuntimeError("logic error: frame %s from higher layer has local MAC address as dest (%s)",
                frame->getFullName(), frame->getDest().str().c_str());
    }

    if (frame->getByteLength() > MAX_ETHERNET_FRAME_BYTES) {    //FIXME two MAX FRAME BYTES in specif...
        throw cRuntimeError("packet from higher layer (%d bytes) exceeds maximum Ethernet frame size (%d)",
                (int)(frame->getByteLength()), MAX_ETHERNET_FRAME_BYTES);
    }

    if (!connected || disabled) {
        EV_WARN << (!connected ? "Interface is not connected" : "MAC is disabled") << " -- dropping packet " << frame << endl;
        emit(dropPkFromHLIfaceDownSignal, frame);
        numDroppedPkFromHLIfaceDown++;
        delete frame;

        requestNextFrameFromExtQueue();
        return;
    }

    // fill in src address if not set
    if (frame->getSrc().isUnspecified())
        frame->setSrc(address);

    bool isPauseFrame = (dynamic_cast<EtherPauseFrame *>(frame) != nullptr);

    if (!isPauseFrame) {
        numFramesFromHL++;
        emit(rxPkFromHLSignal, frame);
    }
    //EV<<"debug marked: Src"<<curTxFrame->getSrc().str().c_str()<<endl;
    //EV<<"Dst"<<curTxFrame->getDest().str().c_str()<<endl;
    if (txQueue.extQueue) {
        //curTxFrame = nullptr;
        //transmitState = TX_IDLE_STATE;
        if(curTxFrame != nullptr){
          //  txQueue.extQueue->(frame);


            return;} // 20200413
       ASSERT(curTxFrame == nullptr);
       ASSERT(transmitState == TX_IDLE_STATE || transmitState == PAUSE_STATE);
        curTxFrame = frame;
    }
    else {
        if (txQueue.innerQueue->isFull())
            throw cRuntimeError("txQueue length exceeds %d -- this is probably due to "
                                "a bogus app model generating excessive traffic "
                                "(or if this is normal, increase txQueueLimit!)",
                    txQueue.innerQueue->getQueueLimit());
        // store frame and possibly begin transmitting
        EV_DETAIL << "Frame " << frame << " arrived from higher layers, enqueueing\n";
        txQueue.innerQueue->insertFrame(frame);
        if (!curTxFrame && !txQueue.innerQueue->isEmpty() && transmitState == TX_IDLE_STATE)
            curTxFrame = (EtherFrame *)txQueue.innerQueue->pop();
    }
    //2018.08.28
    bool TSNswitch =par("TSNswitch");
    if(TSNswitch)
      {
          {
              CacheTraffic(curTxFrame);

              if(transmitState==TX_IDLE_STATE){
                  startQFramesTransmission();
                 // OldstartQFramesTransmission();
              }else{
                   EV<<"Now scurrent state=not idle  "<<transmitState<<endl;  // shi bu shi ying gai pan duan ran hou deng dai
                  }
          }
      }

    if (transmitState == TX_IDLE_STATE&&!TSNswitch)    //Other Normal transmission

       {

              module = getParentModule()->getParentModule()->getName();
             EV<<"Now in other index of " <<module<< ", Start Normal Transmission.";
             startFrameTransmission();
        }


}
void EtherMACFullDuplex::processMsgFromNetwork(cPacket *pk)
{
    EtherTraffic *msg = check_and_cast<EtherTraffic *>(pk);

    EV_INFO << msg << " received." << endl;

    if (!connected || disabled) {
        EV_WARN << (!connected ? "Interface is not connected" : "MAC is disabled") << " -- dropping msg " << msg << endl;
        if (EtherPhyFrame *phyFrame = dynamic_cast<EtherPhyFrame *>(msg)) {    // do not count JAM and IFG packets
            EtherFrame *frame = decapsulate(phyFrame);
            emit(dropPkIfaceDownSignal, frame);
            delete frame;
            numDroppedIfaceDown++;
        }
        else
            delete msg;

        return;
    }

    EtherPhyFrame *phyFrame = dynamic_cast<EtherPhyFrame *>(msg);
    if (!phyFrame) {
        if (dynamic_cast<EtherFilledIFG *>(msg))
            throw cRuntimeError("There is no burst mode in full-duplex operation: EtherFilledIFG is unexpected");
        else
            throw cRuntimeError("Unexpected ethernet traffic: %s", msg->getClassName());
    }

    totalSuccessfulRxTime += phyFrame->getDuration();

    bool hasBitError = msg->hasBitError();

    EtherFrame *frame = decapsulate(phyFrame);
    emit(packetReceivedFromLowerSignal, frame);

    if (hasBitError) {
        numDroppedBitError++;
        emit(dropPkBitErrorSignal, frame);
        delete frame;
        return;
    }

    if (dropFrameNotForUs(frame))
        return;

    if (dynamic_cast<EtherPauseFrame *>(frame) != nullptr) {
        int pauseUnits = ((EtherPauseFrame *)frame)->getPauseTime();
        delete frame;
        numPauseFramesRcvd++;
        emit(rxPausePkUnitsSignal, pauseUnits);
        processPauseCommand(pauseUnits);
    }
    else {
        EV_INFO << "Reception of " << frame << " successfully completed." << endl;
        processReceivedDataFrame((EtherFrame *)frame);
    }
}
void EtherMACFullDuplex::handleEndIFGPeriod()
{

    //2020
    //curTxFrame =nullptr;
   // transmitState= WAIT_IFG_STATE;

    ASSERT(nullptr == curTxFrame);
    if (transmitState != WAIT_IFG_STATE)
        throw cRuntimeError("Not in WAIT_IFG_STATE at the end of IFG period");

    // End of IFG period, okay to transmit
    EV_DETAIL << "IFG elapsed" << endl;

    getNextFrameFromQueue();
    //2018.08.28

    bool TSNswitch = par("TSNswitch");
    if(TSNswitch)
    {
        {
            EV<<" handleENDIFGPeriod TSN port"<<endl;
            transmitState = TX_IDLE_STATE;
            emit(transmitStateSignal, TX_IDLE_STATE);
            IDLEstartQFramesTransmission();
        }
    }
    else
    {
        beginSendFrames();
    }

}
void EtherMACFullDuplex::handleEndTxPeriod()
{
    // we only get here if transmission has finished successfully
    if (transmitState != TRANSMITTING_STATE)
        throw cRuntimeError("End of transmission, and incorrect state detected");

    if (nullptr == curTxFrame)
        throw cRuntimeError("Frame under transmission cannot be found");

    emit(packetSentToLowerSignal, curTxFrame);    //consider: emit with start time of frame

    if (dynamic_cast<EtherPauseFrame *>(curTxFrame) != nullptr) {
        numPauseFramesSent++;
        emit(txPausePkUnitsSignal, ((EtherPauseFrame *)curTxFrame)->getPauseTime());
    }
    else {
        unsigned long curBytes = curTxFrame->getByteLength();
        numFramesSent++;
        numBytesSent += curBytes;
        emit(txPkSignal, curTxFrame);
    }

   delete curTxFrame;

  //  curTxFrame->drop();

    curTxFrame = nullptr;
    lastTxFinishTime = simTime();
    EV<<"Now Last finish time = "<<lastTxFinishTime<<endl;

    if (pauseUnitsRequested > 0) {
        // if we received a PAUSE frame recently, go into PAUSE state
        EV_DETAIL << "Going to PAUSE mode for " << pauseUnitsRequested << " time units\n";

        scheduleEndPausePeriod(pauseUnitsRequested);
        pauseUnitsRequested = 0;
    }
    else {
        EV_DETAIL << "Start IFG period\n";
        scheduleEndIFGPeriod();
    }
}
void EtherMACFullDuplex::finish()
{
    EtherMACBase::finish();

    simtime_t t = simTime();
    simtime_t totalRxChannelIdleTime = t - totalSuccessfulRxTime;
    recordScalar("rx channel idle (%)", 100 * (totalRxChannelIdleTime / t));
    recordScalar("rx channel utilization (%)", 100 * (totalSuccessfulRxTime / t));
}
void EtherMACFullDuplex::handleEndPausePeriod()
{
    ASSERT(nullptr == curTxFrame);
    if (transmitState != PAUSE_STATE)
        throw cRuntimeError("End of PAUSE event occurred when not in PAUSE_STATE!");

    EV_DETAIL << "Pause finished, resuming transmissions\n";
    getNextFrameFromQueue();
    beginSendFrames();
}
void EtherMACFullDuplex::processReceivedDataFrame(EtherFrame *frame)
{
    // statistics
    unsigned long curBytes = frame->getByteLength();
    long count = 0;
    numFramesReceivedOK++;
    numBytesReceivedOK += curBytes;
    emit(rxPkOkSignal, frame);

    numFramesPassedToHL++;
    emit(packetSentToUpperSignal, frame);
    double delay_c = par("delay_c");
    bool record_D = par("analysis_delay");

    int64_t  frame_L = 0;
    MACAddress dmac = frame -> getDest();
    std::string str_dmac = dmac.str();

    int l_dmac = sizeof(dmac);
    int k = 1;
    //int offset = (MAC_ADDRESS_SIZE - k - 1) * 8;
   // unsigned char k_dmac = 0xff & (address >> offset);
    //const std::type_info t_dmac = typeid(dmac);
    const char *mac1= "00-00-29-00-00-01";
    curnode = this -> getParentModule() -> getParentModule()-> getName();
    EV<<"marked2020"<<curnode<<endl;

    if (curnode == "tsn_es14"){

        if (str_dmac == "00-00-14-00-00-01") { emit(Re2eflow1,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-02") { emit(Re2eflow2,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-05") { emit(Re2eflow5,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-06") { emit(Re2eflow6,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-11") { emit(Re2eflow11,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-12") { emit(Re2eflow12,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-13") { emit(Re2eflow13,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-14") { emit(Re2eflow14,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-15") { emit(Re2eflow15,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-16") { emit(Re2eflow16,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-17") { emit(Re2eflow17,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-14-00-00-18") { emit(Re2eflow18,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }

    if (curnode == "tsn_es7"){

        if (str_dmac == "00-00-07-00-00-03") { emit(Re2eflow3,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-07-00-00-04") { emit(Re2eflow4,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
    }

    if (curnode == "tsn_es13"){

        if (str_dmac == "00-00-13-00-00-07") { emit(Re2eflow7,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-13-00-00-08") { emit(Re2eflow8,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-13-00-00-09") { emit(Re2eflow9,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-13-00-00-10") { emit(Re2eflow10,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
    }
    if (curnode == "tsn_es27"){

        if (str_dmac == "00-00-27-00-00-19") { emit(Re2eflow19,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }
    if (curnode == "tsn_es20"){

        if (str_dmac == "00-00-20-00-00-20") { emit(Re2eflow20,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }
    if (curnode == "tsn_es21"){

        if (str_dmac == "00-00-21-00-00-21") { emit(Re2eflow21,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-22") { emit(Re2eflow22,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-23") { emit(Re2eflow23,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-24") { emit(Re2eflow24,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-25") { emit(Re2eflow25,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-26") { emit(Re2eflow26,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-27") { emit(Re2eflow27,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-28") { emit(Re2eflow28,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-29") { emit(Re2eflow29,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-30") { emit(Re2eflow30,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-31") { emit(Re2eflow31,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}
        if (str_dmac == "00-00-21-00-00-32") { emit(Re2eflow32,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }
    if (curnode == "tsn_es15"){

        if (str_dmac == "00-00-15-00-00-33") { emit(Re2eflow33,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }
    if (curnode == "tsn_es23"){

        if (str_dmac == "00-00-23-00-00-34") { emit(Re2eflow34,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }

    if (curnode == "tsn_es11"){

        if (str_dmac == "00-00-11-00-00-35") { emit(Re2eflow35,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }
    if (curnode == "tsn_es12"){

        if (str_dmac == "00-00-12-00-00-36") { emit(Re2eflow36,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);}

    }





    if(  curnode == "tsn_es28" ) {EV<<"marked: in es28"<<endl;}
    if(  curnode  == "tsn_es29" )
    {
        if (str_dmac == "00-00-29-00-00-01") {
            EV<<"ES29 MAC01"<<endl;
            emit(Re2eflow37,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);
        }
        if (str_dmac == "00-00-29-00-00-02") {EV<<"ES29 MAC02"<<endl;

        emit(Re2eflow38,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);
        }
    }

    EV<<"marked2020 AAA "<<str_dmac<<endl;
    EV<<"now mac"<<address<<endl;
    //EV<<"length  BBB "<<l_dmac<<endl;
    if(record_D)
    {

//1111-p2-e2e-start
//2023-03-14 12:38:52
if(str_dmac == "AA-AA-00-00-01-12"){  emit(ST_markedTSNflow1,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);  }
if(str_dmac == "AA-AA-00-00-02-12"){  emit(ST_markedTSNflow2,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);  }
//1111-p2-e2e-end
        EV<<"2021-11-21 Record delay"<<address<<endl;
        emit(recordDelay,(simTime().dbl()-frame->getCreationTime().dbl()-delay_c)*1000000);

    }

    bool record_rx = par("analysis_Rxnum");
    if (record_rx)
    {
        emit(recordCount,count++);
    }

    // pass up to upper layer
    EV_INFO << "Sending " << frame << " to upper layer.\n";
    send(frame, "upperLayerOut");
}
void EtherMACFullDuplex::processPauseCommand(int pauseUnits)
{
    if (transmitState == TX_IDLE_STATE) {
        EV_DETAIL << "PAUSE frame received, pausing for " << pauseUnitsRequested << " time units\n";
        if (pauseUnits > 0)
            scheduleEndPausePeriod(pauseUnits);
    }
    else if (transmitState == PAUSE_STATE) {
        EV_DETAIL << "PAUSE frame received, pausing for " << pauseUnitsRequested
                  << " more time units from now\n";
        cancelEvent(endPauseMsg);

        if (pauseUnits > 0)
            scheduleEndPausePeriod(pauseUnits);
    }
    else {
        // transmitter busy -- wait until it finishes with current frame (endTx)
        // and then it'll go to PAUSE state
        EV_DETAIL << "PAUSE frame received, storing pause request\n";
        pauseUnitsRequested = pauseUnits;
    }
}
void EtherMACFullDuplex::scheduleEndIFGPeriod()
{
    ASSERT(nullptr == curTxFrame);
    transmitState = WAIT_IFG_STATE;
    emit(transmitStateSignal, WAIT_IFG_STATE);
    simtime_t endIFGTime = simTime() + (INTERFRAME_GAP_BITS / curEtherDescr->txrate);
    scheduleAt(endIFGTime, endIFGMsg);
}
void EtherMACFullDuplex::scheduleEndPausePeriod(int pauseUnits)
{
    ASSERT(nullptr == curTxFrame);
    // length is interpreted as 512-bit-time units
    simtime_t pausePeriod = ((pauseUnits * PAUSE_UNIT_BITS) / curEtherDescr->txrate);
    scheduleAt(simTime() + pausePeriod, endPauseMsg);
    transmitState = PAUSE_STATE;
    emit(transmitStateSignal, PAUSE_STATE);
}
void EtherMACFullDuplex::beginSendFrames()
{

    EV<<"now in beginSendFrames"<<endl;
    if (curTxFrame) {

        EV_DETAIL << "Transmit next frame in output queue\n";
        startFrameTransmission();

    }
    else {
        // No more frames set transmitter to idle
        transmitState = TX_IDLE_STATE;
        emit(transmitStateSignal, TX_IDLE_STATE);
        if (!txQueue.extQueue) {
            // Output only for internal queue (we cannot be shure that there
            //are no other frames in external queue)
            EV_DETAIL << "No more frames to send, transmitter set to idle\n";
        }
    }
}

static char *fgetline(FILE *fp)
{
    // alloc buffer and read a line
    char *line = new char[MAXLINE];
    if (fgets(line, MAXLINE, fp) == nullptr) {
        delete[] line;
        return nullptr;
    }

    // chop CR/LF
    line[MAXLINE - 1] = '\0';
    int len = strlen(line);
    while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r'))
        line[--len] = '\0';

    return line;
}

void EtherMACFullDuplex::DynamicReadFile(const char *filename)   //2018.08.28
{
   FILE *swfp1 = fopen(filename,"r");
    char *line;
    if(!swfp1)
    {
        EV<<"No files"<<endl;
    }
    else
    {
        while(line = fgetline(swfp1))
        {
            configlist[currentline][0] = strtok(line, " \t");
            configlist[currentline][1]  = strtok(NULL, " \t");
            configlist[currentline][2]  = strtok(NULL, " \t");
            currentline ++;      // 1需要一个判断最大行数和当前行数比较的函数，
            //最大行100，不加判断可能造成bug
        }

    }

    fclose(swfp1);
}


} // namespace inet

