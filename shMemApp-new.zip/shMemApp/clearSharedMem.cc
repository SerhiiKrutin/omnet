#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <iostream>

int main() {
    // 打开共享内存
    int fd1 = shm_open("Shared_Memory_App1", O_CREAT | O_RDWR, 0666);
    int fd2 = shm_open("Shared_Memory_App2", O_RDONLY, 0666);

    // 关闭文件描述符
    close(fd1);
    close(fd2);

    // 删除共享内存
    if (shm_unlink("Shared_Memory_App1") != 0) {
        perror("Error deleting Shared_Memory_App1");
    } else {
        std::cout << "Shared_Memory_App1 deleted successfully" << std::endl;
    }

    if (shm_unlink("Shared_Memory_App2") != 0) {
        perror("Error deleting Shared_Memory_App2");
    } else {
        std::cout << "Shared_Memory_App2 deleted successfully" << std::endl;
    }

    return 0;
}

