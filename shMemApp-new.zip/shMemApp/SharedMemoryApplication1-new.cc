#include "SharedMemoryApplication.h"

int main(int argc, char *argv[]) {
	string udpConfData = "a2ES1,a2ES1:1100,a3ES2:1000,best-effort,10,10,0\n"
//				"a1ES3,a1ES3:2000,a2ES4:2000,video,10,20,4\n"
//				"a1ES4,a1ES4:1000,a2ES4:1000,best-effort,10,10,0\n"
				"a2ES1,a2ES1:1000,a3ES1:1000,best-effort,10,10,0\n";
//            "a3ES6,a3ES6:1000,wirelessHost[0]:1000,best-effort,10,10,0";

	const int SIZE = 1024 * 32;
   	int fd = shm_open("Shared_Memory_App1", O_CREAT | O_RDWR, 0666);
   	ftruncate(fd, SIZE);
   	void* ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
   	memset(ptr, 0, SIZE);
   	sprintf((char*)ptr, "%s", udpConfData.c_str());
   	munmap(ptr, SIZE);
   	close(fd);

}
