#include "SharedMemoryApplication.h"

int main(int argc, char *argv[]) {
	string netConfData = "gating,a1ES3,0,0,1,10.4,4.3-6.2\n"
            "gating,a1ES3,0,1,1,10.3,4.2-6.4-7.8-8.9\n"
            "gating,a1ES3,0,2,1,10.3,4.2-6.4-7.8-8.9\n"
            "gating,a1ES3,0,3,1,10.3,4.2-6.4-7.8-8.9\n"
            "gating,a1ES3,0,4,1,10.3,4.2-6.4-7.8-8.9\n"
            "gating,a1SW3,3,0,0,11.5,200-300\n"
            "gating,a1SW3,3,1,1,11.5,200-300\n"
            "gating,a1SW3,3,2,0,11.5,200-300\n"
            "gating,a1SW3,3,3,0,11.5,200-300\n"
            "gating,a1SW3,3,4,0,11.5,200-300\n"
            "gating,a1SW3,3,5,0,11.5,200-300\n"
            "gating,a1SW3,3,6,0,11.5,200-300\n"
            "gating,a1SW3,3,7,0,11.5,200-300\n"
            "gating,a1SW3,1,1,0,11.5,200-300\n"
            "routing,a2SW1,a3ES1,3";

	const int SIZE = 1024 * 32;
   	int fd = shm_open("Shared_Memory_App3", O_CREAT | O_RDWR, 0666);
   	ftruncate(fd, SIZE);
   	void* ptr = mmap(0, SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
   	memset(ptr, 0, SIZE);
   	sprintf((char*)ptr, "%s", netConfData.c_str());
   	munmap(ptr, SIZE);
   	close(fd);

}

