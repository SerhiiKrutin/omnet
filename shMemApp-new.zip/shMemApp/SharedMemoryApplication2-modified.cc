#include "SharedMemoryApplication.h"
#include <string>
#include <iostream>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

using namespace std;

int main(int argc, char *argv[]) {
    string lastReadData; // 用于存储上次读取的数据
    const int SIZE = 1024 * 64;

    while(1) {
        int fd = shm_open("Shared_Memory_App2", O_RDONLY, 0666);
        if (fd == -1) {
            cerr << "Wait for shared memory: " << "Shared_Memory_App2" << endl;
            sleep(2);
            continue;
        }

        void* ptr = mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
        if (ptr == MAP_FAILED) {
            cerr << "Error mapping shared memory: " << "Shared_Memory_App2" << endl;
            close(fd);
            sleep(2);
            continue;
        }

        string readData(static_cast<char*>(ptr), SIZE);
        munmap(ptr, SIZE);
        close(fd);

        // 检查数据是否为空或是否与上次读取的数据相同
        if (readData.empty() || readData == lastReadData) {
            cerr << "No new data or empty data in: " << "Shared_Memory_App2" << endl;
            sleep(2);
            continue;
        } else {
            // 打印新数据
            cout << "\n\nNew Data from Shared_Memory_App2:\n" << readData << endl;
            lastReadData = readData; // 更新最后读取的数据
        }

        sleep(2);
    }    
}

