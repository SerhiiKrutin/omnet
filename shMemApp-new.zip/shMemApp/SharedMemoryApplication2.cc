#include "SharedMemoryApplication.h"

int main(int argc, char *argv[]) {
	while(1) {
		int fd = shm_open("Shared_Memory_App2", O_RDONLY, 0666);
		if (fd == -1) {
			cerr << "Wait for shared memory: " << "Shared_Memory_App2" << std::endl;
			continue;
		}
	
		const int SIZE = 1024 * 64;
		void* ptr = mmap(0, SIZE, PROT_READ, MAP_SHARED, fd, 0);
		if (ptr == MAP_FAILED) {
			cerr << "Error mapping shared memory: " << "Shared_Memory_App2" << std::endl;
			close(fd);
			continue;
		}
	
		string readData(static_cast<char*>(ptr), SIZE);
		munmap(ptr, SIZE);
		close(fd);
	
		if (readData.empty()) {
			cerr << "Wait for updating: " << "Shared_Memory_App2" << std::endl;
			continue;
		} else {
		cout<<"\n\n"<<endl;
			cout << "Data from CNC: " << "Shared_Memory_App2" << "\n" << readData << endl;
		}

		sleep(2);
	}    
}
